<?php
require_once __DIR__ . '/../includes/auth.php';
redirectIfNotLoggedIn();
if (!isAdmin()) {
    header('Location: ../auth/login.php');
    exit();
}

require_once __DIR__ . '/../config/database.php';

// Get pending requests
$stmt = $pdo->prepare("SELECT sr.*, u.username as requester_name 
                      FROM service_requests sr 
                      JOIN users u ON sr.requester_id = u.id 
                      WHERE sr.status = 'pending' 
                      ORDER BY sr.created_at DESC");
$stmt->execute();
$pendingRequests = $stmt->fetchAll();

// Get recent requests
$recentStmt = $pdo->prepare("SELECT sr.*, u.username as requester_name 
                            FROM service_requests sr 
                            JOIN users u ON sr.requester_id = u.id 
                            ORDER BY sr.created_at DESC 
                            LIMIT 5");
$recentStmt->execute();
$recentRequests = $recentStmt->fetchAll();

// Get technicians
$techStmt = $pdo->prepare("SELECT * FROM users WHERE role = 'technician'");
$techStmt->execute();
$technicians = $techStmt->fetchAll();

// Get unread notifications
$notificationStmt = $pdo->prepare("SELECT COUNT(*) as unread FROM notifications WHERE user_id = ? AND is_read = FALSE");
$notificationStmt->execute([$_SESSION['user_id']]);
$unreadNotifications = $notificationStmt->fetch()['unread'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - Online Services Routing System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css">
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        .modal-dialog {
            max-width: 600px;
        }
        .modal-body {
            max-height: 70vh;
            overflow-y: auto;
        }
    </style>
</head>
<body>
    <?php include __DIR__ . '/../includes/header.php'; ?>
    
    <div class="container mt-4 dashboard-container">
        <div class="row">
            <div class="col-md-3">
                <div class="card dashboard-card">
                    <div class="card-header">
                        <h5>Admin Menu</h5>
                    </div>
                    <div class="card-body">
                        <ul class="nav flex-column">
                            <li class="nav-item">
                                <a class="nav-link active" href="dashboard.php">Dashboard</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="assign_request.php">Assign Requests</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="manage_users.php">Manage Users</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="../auth/logout.php">Logout</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="col-md-9 dashboard-content">
                <div class="card dashboard-card">
                    <div class="card-header">
                        <h5>Dashboard Overview</h5>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-4">
                                <a href="assign_request.php" class="text-decoration-none">
                                    <div class="card bg-primary text-white mb-3">
                                        <div class="card-body">
                                            <h5 class="card-title">Pending Requests</h5>
                                            <p class="card-text display-6"><?php echo count($pendingRequests); ?></p>
                                        </div>
                                    </div>
                                </a>
                            </div>
                            <div class="col-md-4">
                                <a href="manage_users.php" class="text-decoration-none">
                                    <div class="card bg-success text-white mb-3">
                                        <div class="card-body">
                                            <h5 class="card-title">Active Technicians</h5>
                                            <p class="card-text display-6"><?php echo count($technicians); ?></p>
                                        </div>
                                    </div>
                                </a>
                            </div>
                            <div class="col-md-4">
                                <a href="notifications.php" class="text-decoration-none">
                                    <div class="card bg-warning text-white mb-3">
                                        <div class="card-body">
                                            <h5 class="card-title">Unread Notifications</h5>
                                            <p class="card-text display-6"><?php echo $unreadNotifications; ?></p>
                                        </div>
                                    </div>
                                </a>
                            </div>
                        </div>

                        <h5 class="mt-4">Recent Requests</h5>
                        <div class="table-responsive">
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Requester</th>
                                        <th>Title</th>
                                        <th>Status</th>
                                        <th>Created</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($recentRequests as $request): ?>
                                        <tr>
                                            <td><?php echo $request['id']; ?></td>
                                            <td><?php echo htmlspecialchars($request['requester_name']); ?></td>
                                            <td><?php echo htmlspecialchars($request['title']); ?></td>
                                            <td>
                                                <span class="badge bg-<?php echo $request['status'] === 'pending' ? 'warning' : ($request['status'] === 'completed' ? 'success' : 'info'); ?>">
                                                    <?php echo ucfirst($request['status']); ?>
                                                </span>
                                            </td>
                                            <td><?php echo date('M d, Y', strtotime($request['created_at'])); ?></td>
                                            <td>
                                                <a href="view_request.php?id=<?php echo $request['id']; ?>" class="btn btn-sm btn-info">
                                                    <i class="bi bi-eye"></i> View
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php include __DIR__ . '/../includes/footer.php'; ?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/js/main.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Initialize all modals
            var modals = document.querySelectorAll('.modal');
            modals.forEach(function(modal) {
                new bootstrap.Modal(modal);
            });

            // Add click event listeners to all view buttons
            document.querySelectorAll('[data-bs-toggle="modal"]').forEach(function(button) {
                button.addEventListener('click', function() {
                    var targetModal = document.querySelector(this.getAttribute('data-bs-target'));
                    if (targetModal) {
                        var modal = new bootstrap.Modal(targetModal);
                        modal.show();
                    }
                });
            });
        });
    </script>
</body>
</html>