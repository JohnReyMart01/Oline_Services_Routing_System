<?php
// Get current page filename
$current_page = basename($_SERVER['PHP_SELF']);
?>
<div class="card">
    <div class="card-header">
        <h5>Admin Menu</h5>
    </div>
    <div class="card-body">
        <ul class="nav flex-column">
            <li class="nav-item">
                <a class="nav-link <?php echo $current_page === 'dashboard.php' ? 'active' : ''; ?>" href="dashboard.php">
                    <i class="bi bi-speedometer2"></i> Dashboard
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php echo $current_page === 'assign_request.php' ? 'active' : ''; ?>" href="assign_request.php">
                    <i class="bi bi-list-check"></i> Assign Requests
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php echo $current_page === 'manage_users.php' ? 'active' : ''; ?>" href="manage_users.php">
                    <i class="bi bi-people"></i> Manage Users
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php echo $current_page === 'notifications.php' ? 'active' : ''; ?>" href="notifications.php">
                    <i class="bi bi-bell"></i> Notifications
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="../auth/logout.php">
                    <i class="bi bi-box-arrow-right"></i> Logout
                </a>
            </li>
        </ul>
    </div>
</div> 