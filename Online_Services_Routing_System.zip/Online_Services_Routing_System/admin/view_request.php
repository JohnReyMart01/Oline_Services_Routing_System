<?php
require_once __DIR__ . '/../includes/auth.php';
redirectIfNotLoggedIn();
if (!isAdmin()) {
    header('Location: ../auth/login.php');
    exit();
}

require_once __DIR__ . '/../config/database.php';

// Get request ID from URL
$requestId = isset($_GET['id']) ? (int)$_GET['id'] : 0;

// Get request details
$stmt = $pdo->prepare("SELECT sr.*, 
                      u.username as requester_name,
                      t.username as technician_name,
                      a.assigned_at,
                      a.completed_at
                      FROM service_requests sr 
                      LEFT JOIN assignments a ON sr.id = a.request_id 
                      LEFT JOIN users u ON sr.requester_id = u.id 
                      LEFT JOIN users t ON a.technician_id = t.id 
                      WHERE sr.id = ?");
$stmt->execute([$requestId]);
$request = $stmt->fetch();

// Get completion pictures
$picturesStmt = $pdo->prepare("SELECT cp.*, u.username as technician_name 
                              FROM completion_pictures cp 
                              JOIN users u ON cp.technician_id = u.id 
                              WHERE cp.request_id = ? 
                              ORDER BY cp.uploaded_at DESC");
$picturesStmt->execute([$requestId]);
$completionPictures = $picturesStmt->fetchAll();

// Get report images
$reportStmt = $pdo->prepare("SELECT ri.*, tr.created_at as uploaded_at, u.username as technician_name
                            FROM technician_reports tr
                            JOIN report_images ri ON tr.id = ri.report_id
                            JOIN users u ON tr.technician_id = u.id
                            WHERE tr.request_id = ?
                            ORDER BY tr.created_at DESC");
$reportStmt->execute([$requestId]);
$reportImages = $reportStmt->fetchAll();

if (!$request) {
    header('Location: dashboard.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Request - Online Services Routing System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <?php include __DIR__ . '/../includes/header.php'; ?>
    
    <div class="container mt-4">
        <div class="row">
            <div class="col-md-3">
                <div class="card">
                    <div class="card-header">
                        <h5>Admin Menu</h5>
                    </div>
                    <div class="card-body">
                        <ul class="nav flex-column">
                            <li class="nav-item">
                                <a class="nav-link" href="dashboard.php">Dashboard</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="assign_request.php">Assign Requests</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="manage_users.php">Manage Users</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="../auth/logout.php">Logout</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="col-md-9">
                <div class="card">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h5 class="mb-0">Request Details</h5>
                        <a href="dashboard.php" class="btn btn-secondary btn-sm">
                            <i class="bi bi-arrow-left"></i> Back to Dashboard
                        </a>
                    </div>
                    <div class="card-body">
                        <div class="mb-4">
                            <h4><?php echo htmlspecialchars($request['title']); ?></h4>
                            <div class="mt-3">
                                <p><strong>Requester:</strong> <?php echo htmlspecialchars($request['requester_name']); ?></p>
                                <?php if ($request['technician_name']): ?>
                                    <p><strong>Assigned Technician:</strong> <?php echo htmlspecialchars($request['technician_name']); ?></p>
                                    <p><strong>Assigned At:</strong> <?php echo date('M d, Y H:i', strtotime($request['assigned_at'])); ?></p>
                                <?php endif; ?>
                                <p><strong>Created At:</strong> <?php echo date('M d, Y H:i', strtotime($request['created_at'])); ?></p>
                                <p><strong>Status:</strong> 
                                    <span class="badge bg-<?php echo $request['status'] === 'pending' ? 'warning' : ($request['status'] === 'completed' ? 'success' : 'info'); ?>">
                                        <?php echo ucfirst($request['status']); ?>
                                    </span>
                                </p>
                            </div>
                            <div class="mt-4">
                                <h5>Description</h5>
                                <div class="p-3 bg-light rounded">
                                    <?php echo nl2br(htmlspecialchars($request['description'])); ?>
                                </div>
                            </div>
                        </div>
                        
                        <?php if ($request['status'] === 'pending'): ?>
                            <div class="mt-4">
                                <a href="assign_request.php?id=<?php echo $request['id']; ?>" class="btn btn-primary">
                                    <i class="bi bi-person-plus"></i> Assign Request
                                </a>
                            </div>
                        <?php endif; ?>

                        <?php if ($request['status'] === 'completed'): ?>
                            <div class="mb-4">
                                <h5>Completion Pictures</h5>
                                <?php if (count($completionPictures) > 0 || count($reportImages) > 0): ?>
                                    <div class="row">
                                        <?php foreach ($completionPictures as $picture): ?>
                                            <div class="col-md-4 mb-3">
                                                <div class="card">
                                                    <img src="../<?php echo htmlspecialchars($picture['picture_path']); ?>" 
                                                         class="card-img-top" 
                                                         alt="Completion Picture"
                                                         style="height: 200px; object-fit: cover;">
                                                    <div class="card-body">
                                                        <p class="card-text">
                                                            <small class="text-muted">
                                                                Uploaded by: <?php echo htmlspecialchars($picture['technician_name']); ?><br>
                                                                Date: <?php echo date('M d, Y H:i', strtotime($picture['uploaded_at'])); ?>
                                                            </small>
                                                        </p>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php endforeach; ?>
                                        
                                        <?php foreach ($reportImages as $image): ?>
                                            <div class="col-md-4 mb-3">
                                                <div class="card">
                                                    <img src="../<?php echo htmlspecialchars($image['image_path']); ?>" 
                                                         class="card-img-top" 
                                                         alt="Report Image"
                                                         style="height: 200px; object-fit: cover;">
                                                    <div class="card-body">
                                                        <p class="card-text">
                                                            <small class="text-muted">
                                                                Uploaded by: <?php echo htmlspecialchars($image['technician_name']); ?><br>
                                                                Date: <?php echo date('M d, Y H:i', strtotime($image['uploaded_at'])); ?>
                                                            </small>
                                                        </p>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php endforeach; ?>
                                    </div>
                                <?php else: ?>
                                    <div class="alert alert-info">
                                        No completion pictures have been uploaded yet.
                                    </div>
                                <?php endif; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <?php include __DIR__ . '/../includes/footer.php'; ?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/js/main.js"></script>
</body>
</html> 