<?php
require_once __DIR__ . '/../includes/auth.php';
redirectIfNotLoggedIn();
if (!isAdmin()) {
    header('Location: ../auth/login.php');
    exit();
}

require_once __DIR__ . '/../config/database.php';

// Handle technician update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_technician'])) {
    $technicianId = $_POST['technician_id'];
    $firstName = trim($_POST['first_name']);
    $lastName = trim($_POST['last_name']);
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);
    
    try {
        if (empty($firstName) || empty($lastName) || empty($email)) {
            $error = "First name, last name, and email are required.";
        } else {
            if (!empty($password)) {
                // Update with new password
                $stmt = $pdo->prepare("UPDATE users SET first_name = ?, last_name = ?, email = ?, password = ? WHERE id = ? AND role = 'technician'");
                $stmt->execute([$firstName, $lastName, $email, password_hash($password, PASSWORD_DEFAULT), $technicianId]);
            } else {
                // Update without changing password
                $stmt = $pdo->prepare("UPDATE users SET first_name = ?, last_name = ?, email = ? WHERE id = ? AND role = 'technician'");
                $stmt->execute([$firstName, $lastName, $email, $technicianId]);
            }
            
            if ($stmt->rowCount() > 0) {
                $success = "Technician updated successfully.";
            } else {
                $error = "No changes were made.";
            }
        }
    } catch (PDOException $e) {
        if ($e->getCode() == 23000) {
            $error = "Email already exists.";
        } else {
            $error = "Error updating technician: " . $e->getMessage();
        }
    }
}

// Handle technician deletion
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_technician'])) {
    $technicianId = $_POST['technician_id'];
    
    try {
        // Begin transaction
        $pdo->beginTransaction();
        
        // Check if technician has any assigned tasks
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM assignments WHERE technician_id = ?");
        $stmt->execute([$technicianId]);
        $hasAssignments = $stmt->fetchColumn() > 0;
        
        if ($hasAssignments) {
            $error = "Cannot delete technician with assigned tasks. Please reassign or complete their tasks first.";
        } else {
            // Delete technician
            $stmt = $pdo->prepare("DELETE FROM users WHERE id = ? AND role = 'technician'");
            $stmt->execute([$technicianId]);
            
            if ($stmt->rowCount() > 0) {
                $success = "Technician removed successfully.";
            } else {
                $error = "Failed to remove technician.";
            }
        }
        
        $pdo->commit();
    } catch (PDOException $e) {
        $pdo->rollBack();
        $error = "Error removing technician: " . $e->getMessage();
    }
}

// Get all technicians
$stmt = $pdo->prepare("SELECT * FROM users WHERE role = 'technician' ORDER BY created_at DESC");
$stmt->execute();
$technicians = $stmt->fetchAll();

// Handle new technician registration
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['username'])) {
    $username = trim($_POST['username']);
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);
    $firstName = trim($_POST['first_name']);
    $lastName = trim($_POST['last_name']);
    
    if (empty($username) || empty($email) || empty($password) || empty($firstName) || empty($lastName)) {
        $error = "All fields are required.";
    } else {
        try {
            $stmt = $pdo->prepare("INSERT INTO users (username, email, password, first_name, last_name, role) VALUES (?, ?, ?, ?, ?, 'technician')");
            $stmt->execute([$username, $email, password_hash($password, PASSWORD_DEFAULT), $firstName, $lastName]);
            
            header('Location: manage_users.php?added=1');
            exit();
        } catch (PDOException $e) {
            if ($e->getCode() == 23000) {
                $error = "Username or email already exists.";
            } else {
                $error = "Failed to add technician: " . $e->getMessage();
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Technicians - Online Services Routing System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <?php include __DIR__ . '/../includes/header.php'; ?>
    
    <div class="container mt-4">
        <div class="row">
            <div class="col-md-3">
                <?php include 'sidebar.php'; ?>
            </div>
            <div class="col-md-9">
                <div class="card">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h5 class="mb-0">Manage Technicians</h5>
                        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addTechnicianModal">
                            <i class="bi bi-plus"></i> Add Technician
                        </button>
                    </div>
                    <div class="card-body">
                        <?php if (isset($_GET['added'])): ?>
                            <div class="alert alert-success">Technician added successfully!</div>
                        <?php endif; ?>
                        
                        <?php if (isset($success)): ?>
                            <div class="alert alert-success"><?php echo $success; ?></div>
                        <?php endif; ?>
                        
                        <?php if (isset($error)): ?>
                            <div class="alert alert-danger"><?php echo $error; ?></div>
                        <?php endif; ?>
                        
                        <div class="table-responsive">
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th>Username</th>
                                        <th>Name</th>
                                        <th>Email</th>
                                        <th>Joined</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($technicians as $tech): ?>
                                        <tr>
                                            <td><?php echo htmlspecialchars($tech['username']); ?></td>
                                            <td><?php echo htmlspecialchars($tech['first_name'] . ' ' . $tech['last_name']); ?></td>
                                            <td><?php echo htmlspecialchars($tech['email']); ?></td>
                                            <td><?php echo date('M d, Y', strtotime($tech['created_at'])); ?></td>
                                            <td>
                                                <button class="btn btn-sm btn-primary" onclick="openEditModal(<?php echo $tech['id']; ?>, '<?php echo htmlspecialchars($tech['username']); ?>', '<?php echo htmlspecialchars($tech['first_name']); ?>', '<?php echo htmlspecialchars($tech['last_name']); ?>', '<?php echo htmlspecialchars($tech['email']); ?>')">
                                                    <i class="bi bi-pencil"></i> Edit
                                                </button>
                                                <button class="btn btn-sm btn-danger" data-bs-toggle="modal" data-bs-target="#deleteModal<?php echo $tech['id']; ?>">
                                                    <i class="bi bi-trash"></i> Remove
                                                </button>
                                                
                                                <!-- Delete Confirmation Modal -->
                                                <div class="modal fade" id="deleteModal<?php echo $tech['id']; ?>" tabindex="-1">
                                                    <div class="modal-dialog">
                                                        <div class="modal-content">
                                                            <div class="modal-header">
                                                                <h5 class="modal-title">Confirm Deletion</h5>
                                                                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                                            </div>
                                                            <div class="modal-body">
                                                                <p>Are you sure you want to remove technician <strong><?php echo htmlspecialchars($tech['first_name'] . ' ' . $tech['last_name']); ?></strong>?</p>
                                                                <p class="text-danger">This action cannot be undone.</p>
                                                            </div>
                                                            <div class="modal-footer">
                                                                <form method="POST">
                                                                    <input type="hidden" name="technician_id" value="<?php echo $tech['id']; ?>">
                                                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                                                                    <button type="submit" name="delete_technician" class="btn btn-danger">Remove Technician</button>
                                                                </form>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Edit Modal -->
    <div class="modal fade" id="editModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Edit Technician</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST">
                    <div class="modal-body">
                        <input type="hidden" name="technician_id" id="edit_technician_id">
                        <div class="mb-3">
                            <label class="form-label">Username</label>
                            <input type="text" class="form-control" id="edit_username" disabled>
                            <small class="text-muted">Username cannot be changed</small>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">First Name</label>
                            <input type="text" class="form-control" name="first_name" id="edit_first_name" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Last Name</label>
                            <input type="text" class="form-control" name="last_name" id="edit_last_name" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Email</label>
                            <input type="email" class="form-control" name="email" id="edit_email" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">New Password</label>
                            <input type="password" class="form-control" name="password">
                            <small class="text-muted">Leave blank to keep current password</small>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" name="update_technician" class="btn btn-primary">Save Changes</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <!-- Add Technician Modal -->
    <div class="modal fade" id="addTechnicianModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Add New Technician</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST">
                    <div class="modal-body">
                        <div class="mb-3">
                            <label class="form-label">Username</label>
                            <input type="text" class="form-control" name="username" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Email</label>
                            <input type="email" class="form-control" name="email" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Password</label>
                            <input type="password" class="form-control" name="password" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">First Name</label>
                            <input type="text" class="form-control" name="first_name" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Last Name</label>
                            <input type="text" class="form-control" name="last_name" required>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary">Add Technician</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <?php include __DIR__ . '/../includes/footer.php'; ?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/js/main.js"></script>
    <script>
        let editModal;
        
        document.addEventListener('DOMContentLoaded', function() {
            editModal = new bootstrap.Modal(document.getElementById('editModal'));
        });
        
        function openEditModal(id, username, firstName, lastName, email) {
            document.getElementById('edit_technician_id').value = id;
            document.getElementById('edit_username').value = username;
            document.getElementById('edit_first_name').value = firstName;
            document.getElementById('edit_last_name').value = lastName;
            document.getElementById('edit_email').value = email;
            editModal.show();
        }
    </script>
</body>
</html>