<?php
require_once __DIR__ . '/../includes/auth.php';
redirectIfNotLoggedIn();
if (!isAdmin()) {
    header('Location: ../auth/login.php');
    exit();
}

require_once __DIR__ . '/../config/database.php';

// Get pending requests
$requestStmt = $pdo->prepare("SELECT sr.*, u.username as requester_name 
                             FROM service_requests sr 
                             JOIN users u ON sr.requester_id = u.id 
                             WHERE sr.status = 'pending' 
                             ORDER BY sr.created_at DESC");
$requestStmt->execute();
$pendingRequests = $requestStmt->fetchAll();

// Get technicians
$techStmt = $pdo->prepare("SELECT * FROM users WHERE role = 'technician'");
$techStmt->execute();
$technicians = $techStmt->fetchAll();

// Handle assignment
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['request_id'], $_POST['technician_id'])) {
    $requestId = $_POST['request_id'];
    $technicianId = $_POST['technician_id'];
    
    // Begin transaction
    $pdo->beginTransaction();
    
    try {
        // Update request status
        $updateStmt = $pdo->prepare("UPDATE service_requests SET status = 'assigned' WHERE id = ?");
        $updateStmt->execute([$requestId]);
        
        // Create assignment
        $assignStmt = $pdo->prepare("INSERT INTO assignments (request_id, technician_id) VALUES (?, ?)");
        $assignStmt->execute([$requestId, $technicianId]);
        
        // Notify technician
        createNotification($technicianId, "You have been assigned a new service request.");
        
        $pdo->commit();
        
        header('Location: assign_request.php?assigned=1');
        exit();
    } catch (Exception $e) {
        $pdo->rollBack();
        $error = "Failed to assign request: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Assign Requests - Online Services Routing System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <?php include __DIR__ . '/../includes/header.php'; ?>
    
    <div class="container mt-4">
        <div class="row">
            <div class="col-md-3">
                <div class="card">
                    <div class="card-header">
                        <h5>Admin Menu</h5>
                    </div>
                    <div class="card-body">
                        <ul class="nav flex-column">
                            <li class="nav-item">
                                <a class="nav-link" href="../admin/dashboard.php">Dashboard</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link active" href="../admin/assign_requests.php">Assign Requests</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="../admin/manage_users.php">Manage Users</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="../auth/logout.php">Logout</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="col-md-9">
                <div class="card">
                    <div class="card-header">
                        <h5>Assign Service Requests</h5>
                    </div>
                    <div class="card-body">
                        <?php if (isset($_GET['assigned'])): ?>
                            <div class="alert alert-success">Request assigned successfully!</div>
                        <?php elseif (isset($error)): ?>
                            <div class="alert alert-danger"><?php echo $error; ?></div>
                        <?php endif; ?>
                        
                        <?php if (count($pendingRequests) > 0 && count($technicians) > 0): ?>
                            <div class="table-responsive">
                                <table class="table table-striped">
                                    <thead>
                                        <tr>
                                            <th>Title</th>
                                            <th>Requester</th>
                                            <th>Created At</th>
                                            <th>Assign To</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($pendingRequests as $request): ?>
                                            <tr>
                                                <td><?php echo htmlspecialchars($request['title']); ?></td>
                                                <td><?php echo htmlspecialchars($request['requester_name']); ?></td>
                                                <td><?php echo date('M d, Y H:i', strtotime($request['created_at'])); ?></td>
                                                <td>
                                                    <form method="POST" class="d-flex">
                                                        <input type="hidden" name="request_id" value="<?php echo $request['id']; ?>">
                                                        <select name="technician_id" class="form-select me-2" required>
                                                            <option value="">Select Technician</option>
                                                            <?php foreach ($technicians as $tech): ?>
                                                                <option value="<?php echo $tech['id']; ?>"><?php echo htmlspecialchars($tech['username']); ?></option>
                                                            <?php endforeach; ?>
                                                        </select>
                                                        <button type="submit" class="btn btn-sm btn-primary">Assign</button>
                                                    </form>
                                                </td>
                                                <td>
                                                    <button type="button" class="btn btn-sm btn-info" data-bs-toggle="modal" data-bs-target="#requestModal<?php echo $request['id']; ?>">
                                                        View Details
                                                    </button>
                                                    
                                                    <!-- Modal -->
                                                    <div class="modal fade" id="requestModal<?php echo $request['id']; ?>" tabindex="-1" aria-labelledby="requestModalLabel<?php echo $request['id']; ?>" aria-hidden="true">
                                                        <div class="modal-dialog modal-dialog-centered">
                                                            <div class="modal-content">
                                                                <div class="modal-header">
                                                                    <h5 class="modal-title" id="requestModalLabel<?php echo $request['id']; ?>"><?php echo htmlspecialchars($request['title']); ?></h5>
                                                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                                </div>
                                                                <div class="modal-body">
                                                                    <p><strong>Requester:</strong> <?php echo htmlspecialchars($request['requester_name']); ?></p>
                                                                    <p><strong>Created At:</strong> <?php echo date('M d, Y H:i', strtotime($request['created_at'])); ?></p>
                                                                    <p><strong>Description:</strong></p>
                                                                    <p><?php echo nl2br(htmlspecialchars($request['description'])); ?></p>
                                                                </div>
                                                                <div class="modal-footer">
                                                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php elseif (count($pendingRequests) === 0): ?>
                            <div class="alert alert-info">No pending requests to assign.</div>
                        <?php else: ?>
                            <div class="alert alert-warning">No technicians available to assign requests to.</div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <?php include __DIR__ . '/../includes/footer.php'; ?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Initialize all modals
            var modals = document.querySelectorAll('.modal');
            modals.forEach(function(modal) {
                new bootstrap.Modal(modal);
            });
        });
    </script>
</body>
</html>