<?php
require_once __DIR__ . '/includes/auth.php';

if (isLoggedIn()) {
    redirectBasedOnRole();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Online Services Routing System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        .hero-section {
            background: linear-gradient(rgba(0, 0, 0, 0.7), rgba(0, 0, 0, 0.7)), url('https://via.placeholder.com/1920x600');
            background-size: cover;
            background-position: center;
            color: white;
            padding: 100px 0;
            margin-bottom: 50px;
        }
        .feature-icon {
            font-size: 2.5rem;
            margin-bottom: 1rem;
            color: #0d6efd;
        }
    </style>
</head>
<body>
    <?php include __DIR__ . '/includes/header.php'; ?>
    
    <div class="hero-section text-center">
        <div class="container">
            <h1 class="display-4">Online Services Routing System</h1>
            <p class="lead">Efficiently manage and route service requests between requesters and technicians</p>
            <div class="mt-4">
                <a href="auth/register.php" class="btn btn-primary btn-lg mx-2">Get Started</a>
                <a href="auth/login.php" class="btn btn-outline-light btn-lg mx-2">Login</a>
            </div>
        </div>
    </div>
    
    <div class="container my-5">
        <div class="row text-center">
            <div class="col-md-4 mb-4">
                <div class="feature-icon">
                    <i class="bi bi-person-plus"></i>
                </div>
                <h3>For Requesters</h3>
                <p>Submit service requests and track their progress through the system.</p>
            </div>
            <div class="col-md-4 mb-4">
                <div class="feature-icon">
                    <i class="bi bi-people"></i>
                </div>
                <h3>For Technicians</h3>
                <p>Receive assigned tasks and update their status as you work on them.</p>
            </div>
            <div class="col-md-4 mb-4">
                <div class="feature-icon">
                    <i class="bi bi-gear"></i>
                </div>
                <h3>For Admins</h3>
                <p>Manage users and assign service requests to available technicians.</p>
            </div>
        </div>
    </div>
    
    <?php include __DIR__ . '/includes/footer.php'; ?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/main.js"></script>
</body>
</html>