<?php
require_once __DIR__ . '/../includes/auth.php';
redirectIfNotLoggedIn();
if (!isTechnician()) {
    header('Location: ../auth/login.php');
    exit();
}

require_once __DIR__ . '/../config/database.php';

// Get request ID from URL
$requestId = isset($_GET['id']) ? (int)$_GET['id'] : 0;

// Get report details
$stmt = $pdo->prepare("SELECT sr.*, tr.*, u.username as requester_name,
                      GROUP_CONCAT(ri.image_path) as image_paths
                      FROM service_requests sr 
                      JOIN technician_reports tr ON sr.id = tr.request_id
                      JOIN users u ON sr.requester_id = u.id
                      LEFT JOIN report_images ri ON tr.id = ri.report_id
                      WHERE sr.id = ? AND tr.technician_id = ?
                      GROUP BY tr.id");
$stmt->execute([$requestId, $_SESSION['user_id']]);
$report = $stmt->fetch();

if (!$report) {
    header('Location: tasks.php');
    exit();
}

// Convert image paths to array
$images = $report['image_paths'] ? explode(',', $report['image_paths']) : [];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Report - Online Services Routing System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css">
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        .report-image {
            max-width: 100%;
            height: auto;
            margin-bottom: 1rem;
            border-radius: 0.5rem;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
    </style>
</head>
<body>
    <?php include __DIR__ . '/../includes/header.php'; ?>
    
    <div class="container mt-4">
        <div class="row">
            <div class="col-md-3">
                <div class="card">
                    <div class="card-header">
                        <h5>Technician Menu</h5>
                    </div>
                    <div class="card-body">
                        <ul class="nav flex-column">
                            <li class="nav-item">
                                <a class="nav-link" href="dashboard.php">Dashboard</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link active" href="tasks.php">My Tasks</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="../auth/logout.php">Logout</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="col-md-9">
                <div class="card">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h5 class="mb-0">Completion Report</h5>
                        <a href="tasks.php" class="btn btn-secondary btn-sm">
                            <i class="bi bi-arrow-left"></i> Back to Tasks
                        </a>
                    </div>
                    <div class="card-body">
                        <div class="mb-4">
                            <h4><?php echo htmlspecialchars($report['title']); ?></h4>
                            <div class="mt-3">
                                <p><strong>Requester:</strong> <?php echo htmlspecialchars($report['requester_name']); ?></p>
                                <p><strong>Completion Date:</strong> <?php echo date('M d, Y H:i', strtotime($report['completion_date'])); ?></p>
                                <p><strong>Report Submitted:</strong> <?php echo date('M d, Y H:i', strtotime($report['created_at'])); ?></p>
                            </div>
                            
                            <div class="mt-4">
                                <h5>Report Details</h5>
                                <div class="p-3 bg-light rounded">
                                    <?php echo nl2br(htmlspecialchars($report['report_text'])); ?>
                                </div>
                            </div>
                            
                            <?php if (!empty($images)): ?>
                                <div class="mt-4">
                                    <h5>Completion Images</h5>
                                    <div class="row">
                                        <?php foreach ($images as $image): ?>
                                            <div class="col-md-6 mb-3">
                                                <img src="../<?php echo htmlspecialchars($image); ?>" 
                                                     alt="Completion Image" 
                                                     class="report-image"
                                                     onclick="window.open(this.src, '_blank')">
                                            </div>
                                        <?php endforeach; ?>
                                    </div>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <?php include __DIR__ . '/../includes/footer.php'; ?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/js/main.js"></script>
</body>
</html> 