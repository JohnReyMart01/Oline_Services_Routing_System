<?php
require_once __DIR__ . '/../includes/auth.php';
redirectIfNotLoggedIn();
if (!isTechnician()) {
    header('Location: ../auth/login.php');
    exit();
}

require_once __DIR__ . '/../config/database.php';

// Get user's tasks
$stmt = $pdo->prepare("SELECT sr.*, a.assigned_at, a.completed_at, u.username as requester_name 
                      FROM service_requests sr 
                      JOIN assignments a ON sr.id = a.request_id 
                      JOIN users u ON sr.requester_id = u.id 
                      WHERE a.technician_id = ? 
                      ORDER BY sr.created_at DESC");
$stmt->execute([$_SESSION['user_id']]);
$tasks = $stmt->fetchAll();

// Get unread notifications
$notificationStmt = $pdo->prepare("SELECT COUNT(*) as unread FROM notifications WHERE user_id = ? AND is_read = FALSE");
$notificationStmt->execute([$_SESSION['user_id']]);
$unreadNotifications = $notificationStmt->fetch()['unread'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Technician Dashboard - Online Services Routing System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <?php include __DIR__ . '/../includes/header.php'; ?>
    
    <div class="container mt-4">
        <div class="row">
            <div class="col-md-3">
                <div class="card">
                    <div class="card-header">
                        <h5>Menu</h5>
                    </div>
                    <div class="card-body">
                        <ul class="nav flex-column">
                            <li class="nav-item">
                                <a class="nav-link active" href="dashboard.php">Dashboard</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="tasks.php">My Tasks</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="../auth/logout.php">Logout</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="col-md-9">
                <div class="card">
                    <div class="card-header">
                        <h5>Dashboard Overview</h5>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="card bg-primary text-white mb-3">
                                    <div class="card-body">
                                        <h5 class="card-title">Assigned Tasks</h5>
                                        <p class="card-text display-6"><?php echo count($tasks); ?></p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <a href="notifications.php" class="text-decoration-none">
                                    <div class="card bg-warning text-white mb-3">
                                        <div class="card-body">
                                            <h5 class="card-title">Unread Notifications</h5>
                                            <p class="card-text display-6"><?php echo $unreadNotifications; ?></p>
                                        </div>
                                    </div>
                                </a>
                            </div>
                        </div>

                        <h5 class="mt-4">Recent Tasks</h5>
                        <div class="table-responsive">
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Title</th>
                                        <th>Status</th>
                                        <th>Assigned</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach (array_slice($tasks, 0, 5) as $task): ?>
                                        <tr>
                                            <td><?php echo $task['id']; ?></td>
                                            <td><?php echo htmlspecialchars($task['title']); ?></td>
                                            <td>
                                                <span class="badge bg-<?php 
                                                    switch($task['status']) {
                                                        case 'pending': echo 'warning'; break;
                                                        case 'assigned': echo 'info'; break;
                                                        case 'in_progress': echo 'primary'; break;
                                                        case 'completed': echo 'success'; break;
                                                        default: echo 'secondary';
                                                    }
                                                ?>">
                                                    <?php echo ucfirst($task['status']); ?>
                                                </span>
                                            </td>
                                            <td><?php echo date('M d, Y', strtotime($task['assigned_at'])); ?></td>
                                            <td>
                                                <button type="button" class="btn btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#taskModal<?php echo $task['id']; ?>">
                                                    View
                                                </button>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Task Detail Modals -->
    <?php foreach (array_slice($tasks, 0, 5) as $task): ?>
        <?php
        // Get completion pictures for this task
        $picturesStmt = $pdo->prepare("SELECT cp.*, u.username as technician_name 
                                      FROM completion_pictures cp 
                                      JOIN users u ON cp.technician_id = u.id 
                                      WHERE cp.request_id = ? 
                                      ORDER BY cp.uploaded_at DESC");
        $picturesStmt->execute([$task['id']]);
        $completionPictures = $picturesStmt->fetchAll();
        
        // Get report images
        $reportStmt = $pdo->prepare("SELECT ri.*, tr.created_at as uploaded_at, u.username as technician_name
                                    FROM technician_reports tr
                                    JOIN report_images ri ON tr.id = ri.report_id
                                    JOIN users u ON tr.technician_id = u.id
                                    WHERE tr.request_id = ?
                                    ORDER BY tr.created_at DESC");
        $reportStmt->execute([$task['id']]);
        $reportImages = $reportStmt->fetchAll();
        ?>
        <div class="modal fade" id="taskModal<?php echo $task['id']; ?>" tabindex="-1" aria-labelledby="taskModalLabel<?php echo $task['id']; ?>" aria-hidden="true">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="taskModalLabel<?php echo $task['id']; ?>">Task Details</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <h4><?php echo htmlspecialchars($task['title']); ?></h4>
                        <p class="text-muted">Created on <?php echo date('M d, Y H:i', strtotime($task['created_at'])); ?></p>
                        
                        <div class="mb-3">
                            <span class="badge bg-<?php 
                                switch($task['status']) {
                                    case 'pending': echo 'warning'; break;
                                    case 'assigned': echo 'info'; break;
                                    case 'in_progress': echo 'primary'; break;
                                    case 'completed': echo 'success'; break;
                                    default: echo 'secondary';
                                }
                            ?>">
                                <?php echo ucfirst($task['status']); ?>
                            </span>
                        </div>
                        
                        <div class="mb-3">
                            <h6>Description:</h6>
                            <p><?php echo nl2br(htmlspecialchars($task['description'])); ?></p>
                        </div>
                        
                        <div class="mb-3">
                            <h6>Requester:</h6>
                            <p><?php echo htmlspecialchars($task['requester_name']); ?></p>
                        </div>
                        
                        <div class="mb-3">
                            <h6>Assignment Details:</h6>
                            <p>Assigned on: <?php echo date('M d, Y H:i', strtotime($task['assigned_at'])); ?></p>
                            <?php if ($task['completed_at']): ?>
                                <p>Completed on: <?php echo date('M d, Y H:i', strtotime($task['completed_at'])); ?></p>
                            <?php endif; ?>
                        </div>

                        <?php if ($task['status'] === 'completed'): ?>
                            <div class="mb-4">
                                <h5>Completion Pictures</h5>
                                <?php if (count($completionPictures) > 0 || count($reportImages) > 0): ?>
                                    <div class="row">
                                        <?php foreach ($completionPictures as $picture): ?>
                                            <div class="col-md-4 mb-3">
                                                <div class="card">
                                                    <img src="../<?php echo htmlspecialchars($picture['picture_path']); ?>" 
                                                         class="card-img-top" 
                                                         alt="Completion Picture"
                                                         style="height: 200px; object-fit: cover;">
                                                    <div class="card-body">
                                                        <p class="card-text">
                                                            <small class="text-muted">
                                                                Uploaded by: <?php echo htmlspecialchars($picture['technician_name']); ?><br>
                                                                Date: <?php echo date('M d, Y H:i', strtotime($picture['uploaded_at'])); ?>
                                                            </small>
                                                        </p>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php endforeach; ?>
                                        
                                        <?php foreach ($reportImages as $image): ?>
                                            <div class="col-md-4 mb-3">
                                                <div class="card">
                                                    <img src="../<?php echo htmlspecialchars($image['image_path']); ?>" 
                                                         class="card-img-top" 
                                                         alt="Report Image"
                                                         style="height: 200px; object-fit: cover;">
                                                    <div class="card-body">
                                                        <p class="card-text">
                                                            <small class="text-muted">
                                                                Uploaded by: <?php echo htmlspecialchars($image['technician_name']); ?><br>
                                                                Date: <?php echo date('M d, Y H:i', strtotime($image['uploaded_at'])); ?>
                                                            </small>
                                                        </p>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php endforeach; ?>
                                    </div>
                                <?php else: ?>
                                    <div class="alert alert-info">
                                        No completion pictures have been uploaded yet.
                                    </div>
                                <?php endif; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    </div>
                </div>
            </div>
        </div>
    <?php endforeach; ?>

    <?php include __DIR__ . '/../includes/footer.php'; ?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/js/main.js"></script>
</body>
</html>