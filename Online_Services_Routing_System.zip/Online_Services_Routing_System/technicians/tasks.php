<?php
require_once __DIR__ . '/../includes/auth.php';
redirectIfNotLoggedIn();
if (!isTechnician()) {
    header('Location: ../auth/login.php');
    exit();
}

require_once __DIR__ . '/../config/database.php';

// Mark notifications as read when viewing tasks
$pdo->prepare("UPDATE notifications SET is_read = TRUE WHERE user_id = ?")->execute([$_SESSION['user_id']]);

// Get all tasks
$taskStmt = $pdo->prepare("SELECT sr.*, a.assigned_at, a.completed_at, u.username as requester_name 
                          FROM service_requests sr 
                          JOIN assignments a ON sr.id = a.request_id 
                          JOIN users u ON sr.requester_id = u.id 
                          WHERE a.technician_id = ? 
                          ORDER BY CASE 
                            WHEN sr.status = 'assigned' THEN 1 
                            WHEN sr.status = 'in_progress' THEN 2 
                            ELSE 3 
                          END, a.assigned_at DESC");
$taskStmt->execute([$_SESSION['user_id']]);
$tasks = $taskStmt->fetchAll();

// Handle status update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['task_id'], $_POST['status'])) {
    $taskId = $_POST['task_id'];
    $status = $_POST['status'];
    $notes = isset($_POST['notes']) ? trim($_POST['notes']) : '';
    
    try {
        $pdo->beginTransaction();
        
        // Debug output
        error_log("Updating task status - Task ID: " . $taskId . ", New Status: " . $status);
        
        $updateStmt = $pdo->prepare("UPDATE service_requests SET status = ? WHERE id = ?");
        $result = $updateStmt->execute([$status, $taskId]);
        
        if (!$result) {
            error_log("Failed to update task status: " . print_r($updateStmt->errorInfo(), true));
            throw new Exception("Failed to update task status in database");
        }
        
        // Add progress tracking entry
        $progressStmt = $pdo->prepare("INSERT INTO progress_tracking (request_id, status, notes, created_by) VALUES (?, ?, ?, ?)");
        $progressResult = $progressStmt->execute([$taskId, $status, $notes, $_SESSION['user_id']]);
        
        if (!$progressResult) {
            error_log("Failed to add progress tracking: " . print_r($progressStmt->errorInfo(), true));
            throw new Exception("Failed to track progress");
        }
        
        if ($status === 'completed') {
            $updateAssignmentStmt = $pdo->prepare("UPDATE assignments SET completed_at = NOW() WHERE request_id = ?");
            $result = $updateAssignmentStmt->execute([$taskId]);
            
            if (!$result) {
                error_log("Failed to update assignment completion time: " . print_r($updateAssignmentStmt->errorInfo(), true));
                throw new Exception("Failed to update assignment completion time");
            }
            
            // Handle completion pictures upload
            if (isset($_FILES['completion_pictures'])) {
                $upload_dir = dirname(__DIR__) . '/uploads/completion_pictures/';
                error_log("Upload directory: " . $upload_dir);
                
                if (!file_exists($upload_dir)) {
                    error_log("Creating upload directory");
                    if (!mkdir($upload_dir, 0777, true)) {
                        throw new Exception("Failed to create upload directory");
                    }
                }
                
                if (!is_writable($upload_dir)) {
                    throw new Exception("Upload directory is not writable");
                }
                
                foreach ($_FILES['completion_pictures']['tmp_name'] as $key => $tmp_name) {
                    error_log("Processing file " . ($key + 1));
                    
                    if ($_FILES['completion_pictures']['error'][$key] === UPLOAD_ERR_OK) {
                        $file_name = $_FILES['completion_pictures']['name'][$key];
                        $file_ext = pathinfo($file_name, PATHINFO_EXTENSION);
                        $new_filename = 'completion_' . $taskId . '_' . time() . '_' . $key . '.' . $file_ext;
                        $upload_path = $upload_dir . $new_filename;
                        
                        error_log("Attempting to move file to: " . $upload_path);
                        
                        if (move_uploaded_file($tmp_name, $upload_path)) {
                            error_log("File moved successfully");
                            $db_path = 'uploads/completion_pictures/' . $new_filename;
                            
                            $stmt = $pdo->prepare("INSERT INTO completion_pictures (request_id, technician_id, picture_path) VALUES (?, ?, ?)");
                            $result = $stmt->execute([$taskId, $_SESSION['user_id'], $db_path]);
                            
                            if (!$result) {
                                error_log("Failed to save picture to database: " . print_r($stmt->errorInfo(), true));
                                throw new Exception("Failed to save picture information to database");
                            }
                        } else {
                            $error = error_get_last();
                            error_log("Failed to move uploaded file: " . ($error ? $error['message'] : 'Unknown error'));
                            throw new Exception("Failed to upload one or more pictures");
                        }
                    } else {
                        error_log("File upload error code: " . $_FILES['completion_pictures']['error'][$key]);
                        throw new Exception("Error uploading file: " . $_FILES['completion_pictures']['error'][$key]);
                    }
                }
            }
            
            // Notify requester
            $requesterStmt = $pdo->prepare("SELECT requester_id FROM service_requests WHERE id = ?");
            $requesterStmt->execute([$taskId]);
            $requesterId = $requesterStmt->fetch()['requester_id'];
            
            $titleStmt = $pdo->prepare("SELECT title FROM service_requests WHERE id = ?");
            $titleStmt->execute([$taskId]);
            $title = $titleStmt->fetch()['title'];
            
            createNotification($requesterId, "Your service request '{$title}' has been completed.");

            // Notify admin
            $adminStmt = $pdo->prepare("SELECT id FROM users WHERE role = 'admin'");
            $adminStmt->execute();
            $adminId = $adminStmt->fetch()['id'];
            
            $techStmt = $pdo->prepare("SELECT username FROM users WHERE id = ?");
            $techStmt->execute([$_SESSION['user_id']]);
            $techName = $techStmt->fetch()['username'];
            
            createNotification($adminId, "Service request '{$title}' has been completed by technician {$techName}.");
        }
        
        $pdo->commit();
        header('Location: tasks.php?updated=1');
        exit();
    } catch (Exception $e) {
        $pdo->rollBack();
        error_log("Error updating task: " . $e->getMessage());
        $error = "Failed to update task: " . $e->getMessage();
    }
}

// Get specific task if requested
$currentTask = null;
if (isset($_GET['task_id'])) {
    $currentTaskStmt = $pdo->prepare("SELECT sr.*, a.assigned_at, a.completed_at, u.username as requester_name 
                                     FROM service_requests sr 
                                     JOIN assignments a ON sr.id = a.request_id 
                                     JOIN users u ON sr.requester_id = u.id 
                                     WHERE a.technician_id = ? AND sr.id = ?");
    $currentTaskStmt->execute([$_SESSION['user_id'], $_GET['task_id']]);
    $currentTask = $currentTaskStmt->fetch();
}

// Get progress history for current task
$progressHistory = [];
if (isset($_GET['task_id'])) {
    $progressStmt = $pdo->prepare("
        SELECT pt.*, u.username, u.first_name, u.last_name 
        FROM progress_tracking pt 
        JOIN users u ON pt.created_by = u.id 
        WHERE pt.request_id = ? 
        ORDER BY pt.created_at DESC
    ");
    $progressStmt->execute([$_GET['task_id']]);
    $progressHistory = $progressStmt->fetchAll();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Tasks - Online Services Routing System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <?php include __DIR__ . '/../includes/header.php'; ?>
    
    <div class="container mt-4">
        <div class="row">
            <div class="col-md-3">
                <div class="card">
                    <div class="card-header">
                        <h5>Technician Menu</h5>
                    </div>
                    <div class="card-body">
                        <ul class="nav flex-column">
                            <li class="nav-item">
                                <a class="nav-link" href="dashboard.php">Dashboard</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link active" href="tasks.php">My Tasks</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="../profile.php">My Profile</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="../auth/logout.php">Logout</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="col-md-9">
                <?php if (isset($_GET['updated'])): ?>
                    <div class="alert alert-success mb-3">Task status updated successfully!</div>
                <?php endif; ?>
                
                <div class="card mb-4">
                    <div class="card-header">
                        <h5>My Tasks</h5>
                    </div>
                    <div class="card-body">
                        <?php if (count($tasks) > 0): ?>
                            <div class="table-responsive">
                                <table class="table table-striped">
                                    <thead>
                                        <tr>
                                            <th>Title</th>
                                            <th>Requester</th>
                                            <th>Status</th>
                                            <th>Assigned On</th>
                                            <th>Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($tasks as $task): ?>
                                            <tr>
                                                <td><?php echo htmlspecialchars($task['title']); ?></td>
                                                <td><?php echo htmlspecialchars($task['requester_name']); ?></td>
                                                <td>
                                                    <span class="badge 
                                                        <?php 
                                                            switch($task['status']) {
                                                                case 'pending': echo 'bg-warning'; break;
                                                                case 'assigned': echo 'bg-info'; break;
                                                                case 'in_progress': echo 'bg-primary'; break;
                                                                case 'completed': echo 'bg-success'; break;
                                                                default: echo 'bg-secondary';
                                                            }
                                                        ?>">
                                                        <?php echo ucfirst(str_replace('_', ' ', $task['status'])); ?>
                                                    </span>
                                                </td>
                                                <td><?php echo date('M d, Y H:i', strtotime($task['assigned_at'])); ?></td>
                                                <td>
                                                    <?php if ($task['status'] === 'completed'): ?>
                                                        <a href="view_report.php?id=<?php echo $task['id']; ?>" class="btn btn-sm btn-info">
                                                            <i class="bi bi-file-text"></i> View Report
                                                        </a>
                                                    <?php else: ?>
                                                        <a href="submit_report.php?id=<?php echo $task['id']; ?>" class="btn btn-sm btn-success">
                                                            <i class="bi bi-check-circle"></i> Submit Report
                                                        </a>
                                                    <?php endif; ?>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php else: ?>
                            <div class="alert alert-info">You don't have any assigned tasks.</div>
                        <?php endif; ?>
                    </div>
                </div>
                
                <?php if ($currentTask): ?>
                    <div class="card">
                        <div class="card-header">
                            <h5>Task Details: <?php echo htmlspecialchars($currentTask['title']); ?></h5>
                        </div>
                        <div class="card-body">
                            <div class="mb-4">
                                <p><strong>Requester:</strong> <?php echo htmlspecialchars($currentTask['requester_name']); ?></p>
                                <p><strong>Assigned On:</strong> <?php echo date('M d, Y H:i', strtotime($currentTask['assigned_at'])); ?></p>
                                <?php if ($currentTask['completed_at']): ?>
                                    <p><strong>Completed On:</strong> <?php echo date('M d, Y H:i', strtotime($currentTask['completed_at'])); ?></p>
                                <?php endif; ?>
                                <p><strong>Description:</strong></p>
                                <p><?php echo nl2br(htmlspecialchars($currentTask['description'])); ?></p>
                            </div>
                            
                            <form method="POST" enctype="multipart/form-data">
                                <input type="hidden" name="task_id" value="<?php echo $currentTask['id']; ?>">
                                <div class="mb-3">
                                    <label for="status" class="form-label">Update Status</label>
                                    <select class="form-select" id="status" name="status" required onchange="toggleCompletionPictures()">
                                        <option value="assigned" <?php echo $currentTask['status'] === 'assigned' ? 'selected' : ''; ?>>Assigned</option>
                                        <option value="in_progress" <?php echo $currentTask['status'] === 'in_progress' ? 'selected' : ''; ?>>In Progress</option>
                                        <option value="completed" <?php echo $currentTask['status'] === 'completed' ? 'selected' : ''; ?>>Completed</option>
                                    </select>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="notes" class="form-label">Progress Notes</label>
                                    <textarea class="form-control" id="notes" name="notes" rows="3" placeholder="Add details about the current progress..."></textarea>
                                </div>
                                
                                <div id="completionPicturesField" style="display: none;">
                                    <div class="mb-3">
                                        <label for="completion_pictures" class="form-label">Upload Completion Pictures</label>
                                        <input type="file" class="form-control" id="completion_pictures" name="completion_pictures[]" accept="image/*" multiple required>
                                        <small class="text-muted">You can select multiple pictures. Allowed formats: JPG, PNG, GIF. Max size per file: 5MB</small>
                                    </div>
                                </div>
                                
                                <button type="submit" class="btn btn-primary">Update Status</button>
                            </form>
                            
                            <?php if (!empty($progressHistory)): ?>
                            <div class="mt-4">
                                <h5>Progress History</h5>
                                <div class="timeline">
                                    <?php foreach ($progressHistory as $progress): ?>
                                        <div class="timeline-item">
                                            <div class="timeline-marker"></div>
                                            <div class="timeline-content">
                                                <h6 class="mb-1">
                                                    <?php echo ucfirst(str_replace('_', ' ', $progress['status'])); ?>
                                                    <small class="text-muted float-end">
                                                        <?php echo date('M d, Y H:i', strtotime($progress['created_at'])); ?>
                                                    </small>
                                                </h6>
                                                <p class="mb-1">
                                                    <strong><?php echo htmlspecialchars($progress['first_name'] . ' ' . $progress['last_name']); ?></strong>
                                                    <?php if (!empty($progress['notes'])): ?>
                                                        <br><?php echo nl2br(htmlspecialchars($progress['notes'])); ?>
                                                    <?php endif; ?>
                                                </p>
                                            </div>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <?php include __DIR__ . '/../includes/footer.php'; ?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/js/main.js"></script>
    <script>
        function toggleCompletionPictures() {
            const statusSelect = document.getElementById('status');
            const picturesField = document.getElementById('completionPicturesField');
            
            if (statusSelect.value === 'completed') {
                picturesField.style.display = 'block';
            } else {
                picturesField.style.display = 'none';
            }
        }
        
        // Call on page load to set initial state
        document.addEventListener('DOMContentLoaded', function() {
            toggleCompletionPictures();
        });
    </script>
</body>
</html>