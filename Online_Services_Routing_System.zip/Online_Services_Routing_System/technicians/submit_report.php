<?php
require_once __DIR__ . '/../includes/auth.php';
redirectIfNotLoggedIn();
if (!isTechnician()) {
    header('Location: ../auth/login.php');
    exit();
}

require_once __DIR__ . '/../config/database.php';

// Get request ID from URL
$requestId = isset($_GET['id']) ? (int)$_GET['id'] : 0;

// Verify that this request is assigned to the current technician
$stmt = $pdo->prepare("SELECT sr.*, u.username as requester_name 
                      FROM service_requests sr 
                      JOIN assignments a ON sr.id = a.request_id 
                      JOIN users u ON sr.requester_id = u.id 
                      WHERE sr.id = ? AND a.technician_id = ?");
$stmt->execute([$requestId, $_SESSION['user_id']]);
$request = $stmt->fetch();

if (!$request) {
    header('Location: tasks.php');
    exit();
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $reportText = trim($_POST['report_text']);
    $completionDate = $_POST['completion_date'];
    $errors = [];
    
    if (empty($reportText)) {
        $errors[] = "Report text is required.";
    }
    
    if (empty($completionDate)) {
        $errors[] = "Completion date is required.";
    }
    
    if (empty($_FILES['images']['name'][0])) {
        $errors[] = "At least one image is required.";
    }
    
    if (empty($errors)) {
        try {
            $pdo->beginTransaction();
            
            // Insert report
            $reportStmt = $pdo->prepare("INSERT INTO technician_reports (request_id, technician_id, report_text, completion_date) VALUES (?, ?, ?, ?)");
            $reportStmt->execute([$requestId, $_SESSION['user_id'], $reportText, $completionDate]);
            $reportId = $pdo->lastInsertId();
            
            // Create uploads directory if it doesn't exist
            $uploadDir = __DIR__ . '/../uploads/reports/' . $reportId . '/';
            if (!file_exists($uploadDir)) {
                mkdir($uploadDir, 0777, true);
            }
            
            // Handle image uploads
            foreach ($_FILES['images']['tmp_name'] as $key => $tmp_name) {
                if ($_FILES['images']['error'][$key] === UPLOAD_ERR_OK) {
                    $fileName = $_FILES['images']['name'][$key];
                    $fileExt = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
                    
                    // Generate unique filename
                    $newFileName = uniqid() . '.' . $fileExt;
                    $filePath = 'uploads/reports/' . $reportId . '/' . $newFileName;
                    
                    // Move uploaded file
                    if (move_uploaded_file($tmp_name, $uploadDir . $newFileName)) {
                        // Save image path to database
                        $imageStmt = $pdo->prepare("INSERT INTO report_images (report_id, image_path) VALUES (?, ?)");
                        $imageStmt->execute([$reportId, $filePath]);
                    }
                }
            }
            
            // Update request status to completed
            $updateStmt = $pdo->prepare("UPDATE service_requests SET status = 'completed' WHERE id = ?");
            $updateStmt->execute([$requestId]);
            
            // Notify requester
            createNotification($request['requester_id'], "Your service request '{$request['title']}' has been completed.");
            
            $pdo->commit();
            header('Location: tasks.php?reported=1');
            exit();
            
        } catch (Exception $e) {
            $pdo->rollBack();
            $errors[] = "Failed to submit report: " . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Submit Report - Online Services Routing System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <?php include __DIR__ . '/../includes/header.php'; ?>
    
    <div class="container mt-4">
        <div class="row">
            <div class="col-md-3">
                <div class="card">
                    <div class="card-header">
                        <h5>Technician Menu</h5>
                    </div>
                    <div class="card-body">
                        <ul class="nav flex-column">
                            <li class="nav-item">
                                <a class="nav-link" href="dashboard.php">Dashboard</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link active" href="tasks.php">My Tasks</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="../auth/logout.php">Logout</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="col-md-9">
                <div class="card">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h5 class="mb-0">Submit Completion Report</h5>
                        <a href="tasks.php" class="btn btn-secondary btn-sm">
                            <i class="bi bi-arrow-left"></i> Back to Tasks
                        </a>
                    </div>
                    <div class="card-body">
                        <?php if (!empty($errors)): ?>
                            <div class="alert alert-danger">
                                <ul class="mb-0">
                                    <?php foreach ($errors as $error): ?>
                                        <li><?php echo $error; ?></li>
                                    <?php endforeach; ?>
                                </ul>
                            </div>
                        <?php endif; ?>
                        
                        <div class="mb-4">
                            <h4><?php echo htmlspecialchars($request['title']); ?></h4>
                            <p><strong>Requester:</strong> <?php echo htmlspecialchars($request['requester_name']); ?></p>
                            <p><strong>Description:</strong></p>
                            <div class="p-3 bg-light rounded">
                                <?php echo nl2br(htmlspecialchars($request['description'])); ?>
                            </div>
                        </div>
                        
                        <form method="POST" enctype="multipart/form-data">
                            <div class="mb-3">
                                <label for="completion_date" class="form-label">Completion Date and Time</label>
                                <input type="datetime-local" class="form-control" id="completion_date" name="completion_date" 
                                       value="<?php echo date('Y-m-d\TH:i'); ?>" required>
                            </div>
                            
                            <div class="mb-3">
                                <label for="report_text" class="form-label">Report Details</label>
                                <textarea class="form-control" id="report_text" name="report_text" rows="5" required
                                          placeholder="Describe the work completed, any issues encountered, and the final outcome..."></textarea>
                            </div>
                            
                            <div class="mb-3">
                                <label for="images" class="form-label">Upload Images</label>
                                <input type="file" class="form-control" id="images" name="images[]" multiple accept="image/*" required>
                                <small class="text-muted">You can select multiple images. Supported formats: JPG, PNG, GIF</small>
                            </div>
                            
                            <div class="mt-4">
                                <button type="submit" class="btn btn-primary">
                                    <i class="bi bi-check-circle"></i> Submit Report
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <?php include __DIR__ . '/../includes/footer.php'; ?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/js/main.js"></script>
</body>
</html> 