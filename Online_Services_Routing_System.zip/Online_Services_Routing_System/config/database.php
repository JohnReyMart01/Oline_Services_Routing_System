<?php
// Database configuration
$config = [
    'host' => 'localhost',
    'dbname' => 'online_routing_system',
    'username' => 'root',
    'password' => '',
    'charset' => 'utf8mb4',
    'options' => [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ]
];

try {
    $dsn = "mysql:host={$config['host']};dbname={$config['dbname']};charset={$config['charset']}";
    $pdo = new PDO($dsn, $config['username'], $config['password'], $config['options']);
    
    // Create progress_tracking table if it doesn't exist
    $pdo->exec("CREATE TABLE IF NOT EXISTS progress_tracking (
        id INT AUTO_INCREMENT PRIMARY KEY,
        request_id INT NOT NULL,
        status VARCHAR(50) NOT NULL,
        notes TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        created_by INT NOT NULL,
        FOREIGN KEY (request_id) REFERENCES service_requests(id) ON DELETE CASCADE,
        FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE CASCADE
    )");
} catch (PDOException $e) {
    error_log("Database connection failed: " . $e->getMessage());
    die("A database error occurred. Please try again later.");
}

// Function to safely execute database queries
function executeQuery($sql, $params = []) {
    global $pdo;
    try {
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        return $stmt;
    } catch (PDOException $e) {
        error_log("Query execution failed: " . $e->getMessage());
        throw new Exception("A database error occurred. Please try again later.");
    }
}

// Function to safely fetch a single row
function fetchOne($sql, $params = []) {
    try {
        $stmt = executeQuery($sql, $params);
        return $stmt->fetch();
    } catch (Exception $e) {
        error_log("Fetch one failed: " . $e->getMessage());
        return false;
    }
}

// Function to safely fetch all rows
function fetchAll($sql, $params = []) {
    try {
        $stmt = executeQuery($sql, $params);
        return $stmt->fetchAll();
    } catch (Exception $e) {
        error_log("Fetch all failed: " . $e->getMessage());
        return [];
    }
}
?>