<?php
require_once __DIR__ . '/../includes/auth.php';

if (isLoggedIn()) {
    redirectBasedOnRole();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_once __DIR__ . '/../config/database.php';
    
    $firstName = trim($_POST['first_name']);
    $lastName = trim($_POST['last_name']);
    $username = trim($_POST['username']);
    $email = trim($_POST['email']);
    $password = $_POST['password'];
    $verifyPassword = $_POST['verify_password'];
    $role = $_POST['role']; // Get role from form
    $contact_number = trim($_POST['contact_number']);
    
    // Validate input
    $errors = [];
    
    if (empty($firstName)) {
        $errors[] = "First name is required.";
    } elseif (!preg_match('/^[a-zA-Z ]+$/', $firstName)) {
        $errors[] = "First name can only contain letters and spaces.";
    }
    
    if (empty($lastName)) {
        $errors[] = "Last name is required.";
    } elseif (!preg_match('/^[a-zA-Z ]+$/', $lastName)) {
        $errors[] = "Last name can only contain letters and spaces.";
    }
    
    if (empty($username)) {
        $errors[] = "Username is required.";
    } elseif (!preg_match('/^[a-zA-Z0-9_]+$/', $username)) {
        $errors[] = "Username can only contain letters, numbers, and underscores.";
    } elseif (strlen($username) < 4) {
        $errors[] = "Username must be at least 4 characters long.";
    }
    
    if (empty($email)) {
        $errors[] = "Email is required.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Invalid email format.";
    }
    
    if (empty($password)) {
        $errors[] = "Password is required.";
    } elseif (strlen($password) < 8) {
        $errors[] = "Password must be at least 8 characters long.";
    } elseif (!preg_match('/[A-Za-z]/', $password) || !preg_match('/[0-9]/', $password)) {
        $errors[] = "Password must be alphanumeric (contain both letters and numbers).";
    }
    
    if ($password !== $verifyPassword) {
        $errors[] = "Passwords do not match.";
    }

    if (empty($role)) {
        $errors[] = "Role is required.";
    } elseif (!in_array($role, ['technician', 'requester'])) {
        $errors[] = "Invalid role selected.";
    }
    
    if (empty($contact_number)) {
        $errors[] = "Contact number is required.";
    } elseif (!preg_match('/^[0-9]+$/', $contact_number)) {
        $errors[] = "Invalid contact number format.";
    }
    
    if (empty($errors)) {
        // Check if username or email exists
        $stmt = $pdo->prepare("SELECT id FROM users WHERE username = ? OR email = ?");
        $stmt->execute([$username, $email]);
        
        if ($stmt->rowCount() > 0) {
            $errors[] = "Username or email already exists.";
        } else {
            // Hash password
            $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
            
            // Insert user
            $stmt = $pdo->prepare("INSERT INTO users (first_name, last_name, username, email, password, role, contact_number) VALUES (?, ?, ?, ?, ?, ?, ?)");
            $stmt->execute([$firstName, $lastName, $username, $email, $hashedPassword, $role, $contact_number]);
            
            // Redirect to login
            header('Location: login.php?registered=1');
            exit();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register - Online Services Routing System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css">
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        .password-requirements {
            font-size: 0.9rem;
            color: #6c757d;
            margin-top: 0.25rem;
        }
        .requirement {
            display: flex;
            align-items: center;
            margin-bottom: 0.25rem;
        }
        .requirement i {
            margin-right: 0.5rem;
            font-size: 0.8rem;
        }
        .valid {
            color: #28a745;
        }
        .invalid {
            color: #dc3545;
        }
        .password-toggle {
            cursor: pointer;
            position: absolute;
            right: 10px;
            top: 50%;
            transform: translateY(-50%);
        }
        .password-field {
            position: relative;
        }
    </style>
</head>
<body>
    <?php include __DIR__ . '/../includes/header.php'; ?>
    
    <div class="container mt-4">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header">
                        <h4 class="mb-0">Register</h4>
                    </div>
                    <div class="card-body">
                        <?php if (!empty($errors)): ?>
                            <div class="alert alert-danger">
                                <ul class="mb-0">
                                    <?php foreach ($errors as $error): ?>
                                        <li><?php echo $error; ?></li>
                                    <?php endforeach; ?>
                                </ul>
                            </div>
                        <?php endif; ?>
                        
                        <form method="POST" id="registrationForm">
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label for="first_name" class="form-label">First Name</label>
                                    <input type="text" class="form-control" id="first_name" name="first_name" 
                                           value="<?php echo isset($firstName) ? htmlspecialchars($firstName) : ''; ?>" required>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label for="last_name" class="form-label">Last Name</label>
                                    <input type="text" class="form-control" id="last_name" name="last_name" 
                                           value="<?php echo isset($lastName) ? htmlspecialchars($lastName) : ''; ?>" required>
                                </div>
                            </div>
                            
                            <div class="mb-3">
                                <label for="username" class="form-label">Username</label>
                                <input type="text" class="form-control" id="username" name="username" 
                                       value="<?php echo isset($username) ? htmlspecialchars($username) : ''; ?>" required>
                                <small class="text-muted">4+ characters, letters, numbers and underscores only</small>
                            </div>
                            
                            <div class="mb-3">
                                <label for="email" class="form-label">Email</label>
                                <input type="email" class="form-control" id="email" name="email" 
                                       value="<?php echo isset($email) ? htmlspecialchars($email) : ''; ?>" required>
                            </div>

                            <div class="mb-3">
                                <label for="contact_number" class="form-label">Contact Number</label>
                                <input type="tel" class="form-control" id="contact_number" name="contact_number" 
                                       value="<?php echo isset($contact_number) ? htmlspecialchars($contact_number) : ''; ?>" required>
                            </div>

                            <div class="mb-3">
                                <label for="role" class="form-label">Role</label>
                                <select class="form-select" id="role" name="role" required onchange="toggleCollegeField()">
                                    <option value="">Select Role</option>
                                    <option value="technician" <?php echo isset($role) && $role === 'technician' ? 'selected' : ''; ?>>Technician</option>
                                    <option value="requester" <?php echo isset($role) && $role === 'requester' ? 'selected' : ''; ?>>Requester</option>
                                </select>
                            </div>

                            <div class="mb-3" id="collegeField" style="display: none;">
                                <label for="college_id" class="form-label">College</label>
                                <select class="form-select" id="college_id" name="college_id">
                                    <option value="">Select College</option>
                                    <?php
                                    $colleges = $pdo->query("SELECT * FROM colleges ORDER BY name")->fetchAll();
                                    foreach ($colleges as $college) {
                                        $selected = (isset($college_id) && $college_id == $college['id']) ? 'selected' : '';
                                        echo "<option value='{$college['id']}' {$selected}>{$college['name']} ({$college['code']})</option>";
                                    }
                                    ?>
                                </select>
                            </div>
                            
                            <div class="mb-3">
                                <label for="password" class="form-label">Password</label>
                                <div class="password-field">
                                    <input type="password" class="form-control" id="password" name="password" required>
                                    <span class="password-toggle" onclick="togglePassword('password')">
                                        <i class="bi bi-eye"></i>
                                    </span>
                                </div>
                                <div class="password-requirements">
                                    <div class="requirement" id="length-requirement">
                                        <i class="bi"></i>
                                        <span>At least 8 characters</span>
                                    </div>
                                    <div class="requirement" id="alphanum-requirement">
                                        <i class="bi"></i>
                                        <span>Contains both letters and numbers</span>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="mb-3">
                                <label for="verify_password" class="form-label">Verify Password</label>
                                <div class="password-field">
                                    <input type="password" class="form-control" id="verify_password" name="verify_password" required>
                                    <span class="password-toggle" onclick="togglePassword('verify_password')">
                                        <i class="bi bi-eye"></i>
                                    </span>
                                </div>
                                <div id="password-match" class="text-danger small"></div>
                            </div>
                            
                            <div class="text-center">
                                <button type="submit" class="btn btn-primary px-5" id="submitBtn">Register</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <?php include __DIR__ . '/../includes/footer.php'; ?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/js/main.js"></script>
    <script>
        function togglePassword(fieldId) {
            const passwordInput = document.getElementById(fieldId);
            const icon = passwordInput.nextElementSibling.querySelector('i');
            
            if (passwordInput.type === 'password') {
                passwordInput.type = 'text';
                icon.classList.remove('bi-eye');
                icon.classList.add('bi-eye-slash');
            } else {
                passwordInput.type = 'password';
                icon.classList.remove('bi-eye-slash');
                icon.classList.add('bi-eye');
            }
        }

        function toggleCollegeField() {
            const roleSelect = document.getElementById('role');
            const collegeField = document.getElementById('collegeField');
            const collegeSelect = document.getElementById('college_id');
            
            if (roleSelect.value === 'requester') {
                collegeField.style.display = 'block';
                collegeSelect.required = true;
            } else {
                collegeField.style.display = 'none';
                collegeSelect.required = false;
                collegeSelect.value = '';
            }
        }

        // Call on page load to set initial state
        document.addEventListener('DOMContentLoaded', function() {
            toggleCollegeField();
        });
    </script>
</body>
</html>