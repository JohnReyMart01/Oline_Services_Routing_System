<?php
session_start();
require_once __DIR__ . '/../config/database.php';

// Define base URL
$base_url = '/Online_Services_Routing_System';

function isLoggedIn() {
    return isset($_SESSION['user_id']) && !empty($_SESSION['user_id']);
}

function isAdmin() {
    return isset($_SESSION['role']) && $_SESSION['role'] === 'admin';
}

function isTechnician() {
    return isset($_SESSION['role']) && $_SESSION['role'] === 'technician';
}

function isRequester() {
    return isset($_SESSION['role']) && $_SESSION['role'] === 'requester';
}

function redirectIfNotLoggedIn() {
    global $base_url;
    if (!isLoggedIn()) {
        $_SESSION['redirect_after_login'] = $_SERVER['REQUEST_URI'];
        header("Location: {$base_url}/auth/login.php");
        exit();
    }
}

function redirectBasedOnRole() {
    global $base_url;
    if (isLoggedIn()) {
        if (isAdmin()) {
            header("Location: {$base_url}/admin/dashboard.php");
        } elseif (isTechnician()) {
            header("Location: {$base_url}/technicians/dashboard.php");
        } elseif (isRequester()) {
            header("Location: {$base_url}/requesters/dashboard.php");
        }
        exit();
    }
}

function createNotification($userId, $message) {
    global $pdo;
    try {
        $stmt = $pdo->prepare("INSERT INTO notifications (user_id, message) VALUES (?, ?)");
        $stmt->execute([$userId, $message]);
        return true;
    } catch (PDOException $e) {
        error_log("Error creating notification: " . $e->getMessage());
        return false;
    }
}

function getUserFullName() {
    if (isset($_SESSION['user_id'])) {
        global $pdo;
        try {
            $stmt = $pdo->prepare("SELECT first_name, last_name FROM users WHERE id = ?");
            $stmt->execute([$_SESSION['user_id']]);
            $user = $stmt->fetch();
            return $user ? htmlspecialchars($user['first_name'] . ' ' . $user['last_name']) : '';
        } catch (PDOException $e) {
            error_log("Error fetching user name: " . $e->getMessage());
            return '';
        }
    }
    return '';
}

// Add CSRF protection
function generateCSRFToken() {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function validateCSRFToken($token) {
    return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
}
?>