<?php
// Define base URL if not already defined
if (!isset($base_url)) {
    $base_url = '/Online_Services_Routing_System';
}
?>
<footer class="footer">
    <div class="footer-container">
        <div class="footer-content">
            <div class="footer-text">
                <p>Online Services Routing </p>
                <p>A system for managing service requests and assignments.</p>
                <p>&copy; <?php echo date('Y'); ?> All Rights Reserved</p>
            </div>
        </div>
    </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="<?php echo $base_url; ?>/assets/js/main.js"></script>
</body>
</html>