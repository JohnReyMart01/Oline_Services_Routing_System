<?php
require_once __DIR__ . '/auth.php';

function displayWelcomeMessage() {
    if (isLoggedIn()) {
        global $pdo;
        try {
            $stmt = $pdo->prepare("SELECT first_name, last_name FROM users WHERE id = ?");
            $stmt->execute([$_SESSION['user_id']]);
            $user = $stmt->fetch();
            
            if ($user) {
                $fullName = htmlspecialchars($user['first_name'] . ' ' . $user['last_name']);
                return "Welcome, $fullName (" . ucfirst($_SESSION['role']) . ")";
            }
        } catch (PDOException $e) {
            error_log("Error fetching user details: " . $e->getMessage());
        }
        return "Welcome, " . htmlspecialchars($_SESSION['username']) . " (" . ucfirst($_SESSION['role']) . ")";
    }
    return "";
}

// Define base URL
$base_url = '/Online_Services_Routing_System';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Online Services Routing System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css">
    <link rel="stylesheet" href="<?php echo $base_url; ?>/assets/css/style.css">
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container">
    <a class="navbar-brand" href="<?php echo $base_url; ?>/index.php">
    <img src="<?php echo $base_url; ?>/assets/images/logo.png" 
         alt="System Logo" 
         class="navbar-logo">
    <span class="logo-text">Online Services Routing</span>
</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav me-auto">
                <?php if (isLoggedIn()): ?>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo $base_url . '/' . (isAdmin() ? 'admin/dashboard.php' : (isTechnician() ? 'technicians/dashboard.php' : 'requesters/dashboard.php')); ?>">
                            Dashboard
                        </a>
                    </li>
                <?php endif; ?>
            </ul>
            <ul class="navbar-nav">
                <?php if (isLoggedIn()): ?>
                    <li class="nav-item">
                        <span class="nav-link"><?php echo displayWelcomeMessage(); ?></span>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle profile-icon" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            <?php
                            // Get user's profile picture
                            $stmt = $pdo->prepare("SELECT profile_picture FROM users WHERE id = ?");
                            $stmt->execute([$_SESSION['user_id']]);
                            $profile_picture = $stmt->fetchColumn();
                            
                            // Debug information
                            error_log("Profile picture path: " . $profile_picture);
                            error_log("File exists: " . (file_exists($profile_picture) ? 'Yes' : 'No'));
                            
                            // Convert relative path to absolute path
                            $absolute_path = __DIR__ . '/../' . $profile_picture;
                            error_log("Absolute path: " . $absolute_path);
                            error_log("Absolute path exists: " . (file_exists($absolute_path) ? 'Yes' : 'No'));
                            
                            if ($profile_picture && file_exists($absolute_path)): ?>
                                <img src="<?php echo $base_url . '/' . htmlspecialchars($profile_picture); ?>?v=<?php echo time(); ?>" 
                                     alt="Profile Picture" 
                                     class="rounded-circle"
                                     style="width: 32px; height: 32px; object-fit: cover;">
                            <?php else: ?>
                                <i class="bi bi-person-circle"></i>
                            <?php endif; ?>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                            <li><a class="dropdown-item" href="<?php echo $base_url; ?>/profile.php"><i class="bi bi-person"></i> My Profile</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="<?php echo $base_url; ?>/auth/logout.php"><i class="bi bi-box-arrow-right"></i> Logout</a></li>
                        </ul>
                    </li>
                <?php else: ?>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo $base_url; ?>/auth/login.php">Login</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo $base_url; ?>/auth/register.php">Register</a>
                    </li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</nav>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>