<?php
require_once __DIR__ . '/../includes/auth.php';
redirectIfNotLoggedIn();
if (!isRequester()) {
    header('Location: /auth/login.php');
    exit();
}

require_once __DIR__ . '/../config/database.php';

// Define base URL
$base_url = '/Online_Services_Routing_System';

// Get user's requests
$stmt = $pdo->prepare("SELECT * FROM service_requests WHERE requester_id = ? ORDER BY created_at DESC");
$stmt->execute([$_SESSION['user_id']]);
$requests = $stmt->fetchAll();

// Get unread notifications
$notificationStmt = $pdo->prepare("SELECT COUNT(*) as unread FROM notifications WHERE user_id = ? AND is_read = FALSE");
$notificationStmt->execute([$_SESSION['user_id']]);
$unreadNotifications = $notificationStmt->fetch()['unread'];

// Get user details for profile
$userStmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$userStmt->execute([$_SESSION['user_id']]);
$user = $userStmt->fetch();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Requester Dashboard - Online Services Routing System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <?php include __DIR__ . '/../includes/header.php'; ?>
    
    <div class="container mt-4">
        <div class="row">
            <div class="col-md-3">
                <div class="card">
                    <div class="card-header">
                        <h5>Menu</h5>
                    </div>
                    <div class="card-body">
                        <ul class="nav flex-column">
                            <li class="nav-item">
                                <a class="nav-link active" href="dashboard.php">Dashboard</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="create_request.php">Create Request</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="view_requests.php">View Requests</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="notifications.php">Notifications</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="../auth/logout.php">Logout</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="col-md-9">
                <div class="card">
                    <div class="card-header">
                        <h5>Dashboard Overview</h5>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="card bg-primary text-white mb-3">
                                    <div class="card-body">
                                        <h5 class="card-title">Total Requests</h5>
                                        <p class="card-text display-6"><?php echo count($requests); ?></p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <a href="notifications.php" class="text-decoration-none">
                                    <div class="card bg-warning text-white mb-3">
                                        <div class="card-body">
                                            <h5 class="card-title">Unread Notifications</h5>
                                            <p class="card-text display-6"><?php echo $unreadNotifications; ?></p>
                                        </div>
                                    </div>
                                </a>
                            </div>
                        </div>

                        <h5 class="mt-4">Recent Requests</h5>
                        <div class="table-responsive">
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Title</th>
                                        <th>Status</th>
                                        <th>Created</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach (array_slice($requests, 0, 5) as $request): ?>
                                        <tr>
                                            <td><?php echo $request['id']; ?></td>
                                            <td><?php echo htmlspecialchars($request['title']); ?></td>
                                            <td>
                                                <span class="badge bg-<?php echo $request['status'] === 'pending' ? 'warning' : ($request['status'] === 'completed' ? 'success' : 'info'); ?>">
                                                    <?php echo ucfirst($request['status']); ?>
                                                </span>
                                            </td>
                                            <td><?php echo date('M d, Y', strtotime($request['created_at'])); ?></td>
                                            <td>
                                                <a href="view_requests.php?id=<?php echo $request['id']; ?>" class="btn btn-sm btn-primary">View</a>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Profile Modal -->
    <div class="modal fade" id="profileModal" tabindex="-1" aria-labelledby="profileModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="profileModalLabel">Edit Profile</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form id="profileForm" action="../auth/update_profile.php" method="post" enctype="multipart/form-data">
                        <div class="mb-3 text-center">
                            <?php if (!empty($user['profile_picture'])): ?>
                                <img src="../<?php echo htmlspecialchars($user['profile_picture']); ?>" 
                                     class="rounded-circle mb-2" 
                                     width="150" 
                                     height="150" 
                                     alt="Profile Picture"
                                     id="profileImagePreview">
                            <?php else: ?>
                                <img src="../assets/images/default-profile.png" 
                                     class="rounded-circle mb-2" 
                                     width="150" 
                                     height="150" 
                                     alt="Default Profile"
                                     id="profileImagePreview">
                            <?php endif; ?>
                            <div class="mt-2">
                                <input type="file" class="form-control" id="profilePicture" name="profile_picture" accept="image/*">
                            </div>
                        </div>
                        <div class="mb-3">
                            <label for="username" class="form-label">Username</label>
                            <input type="text" class="form-control" id="username" name="username" value="<?php echo htmlspecialchars($user['username']); ?>" required>
                        </div>
                        <div class="mb-3">
                            <label for="email" class="form-label">Email</label>
                            <input type="email" class="form-control" id="email" name="email" value="<?php echo htmlspecialchars($user['email']); ?>" required>
                        </div>
                        <div class="mb-3">
                            <label for="phone" class="form-label">Phone Number</label>
                            <input type="tel" class="form-control" id="phone" name="phone" value="<?php echo htmlspecialchars($user['phone'] ?? ''); ?>">
                        </div>
                        <div class="mb-3">
                            <label for="password" class="form-label">New Password (leave blank to keep current)</label>
                            <input type="password" class="form-control" id="password" name="password">
                        </div>
                        <div class="mb-3">
                            <label for="confirm_password" class="form-label">Confirm New Password</label>
                            <input type="password" class="form-control" id="confirm_password" name="confirm_password">
                        </div>
                        <input type="hidden" name="user_id" value="<?php echo $_SESSION['user_id']; ?>">
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" form="profileForm" class="btn btn-primary">Save Changes</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Password input with eye icon -->
    <div class="container mt-4">
        <div class="row">
            <div class="col-md-6">
                <div class="position-relative">
                    <input type="password" id="password" class="form-control" placeholder="Password">
                    <span id="togglePassword" style="display:none; position:absolute; right:10px; top:50%; transform:translateY(-50%); cursor:pointer;">
                        <i class="bi bi-eye"></i>
                    </span>
                </div>
            </div>
        </div>
    </div>

    <?php include __DIR__ . '/../includes/footer.php'; ?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/js/main.js"></script>
    <script>
        // Preview profile picture before upload
        document.getElementById('profilePicture').addEventListener('change', function(e) {
            const file = e.target.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    document.getElementById('profileImagePreview').src = e.target.result;
                }
                reader.readAsDataURL(file);
            }
        });

        const passwordInput = document.getElementById('password');
        const togglePassword = document.getElementById('togglePassword');
        let typingTimer;
        const doneTypingInterval = 500; // ms

        passwordInput.addEventListener('input', function() {
            clearTimeout(typingTimer);
            if (passwordInput.value.length > 0) {
                typingTimer = setTimeout(() => {
                    togglePassword.style.display = 'block';
                }, doneTypingInterval);
            } else {
                togglePassword.style.display = 'none';
            }
        });

        togglePassword.addEventListener('click', function() {
            const type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
            passwordInput.setAttribute('type', type);
            this.innerHTML = type === 'password' 
                ? '<i class="bi bi-eye"></i>' 
                : '<i class="bi bi-eye-slash"></i>';
        });
    </script>
</body>
</html>