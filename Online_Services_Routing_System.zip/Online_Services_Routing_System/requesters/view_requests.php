<?php
require_once __DIR__ . '/../includes/auth.php';
redirectIfNotLoggedIn();
if (!isRequester()) {
    header('Location: ../auth/login.php');
    exit();
}

require_once __DIR__ . '/../config/database.php';

// Get user's requests
$stmt = $pdo->prepare("SELECT sr.*, 
                      CASE 
                          WHEN sr.status = 'pending' THEN 'warning'
                          WHEN sr.status = 'completed' THEN 'success'
                          ELSE 'info'
                      END as status_color
                      FROM service_requests sr 
                      WHERE sr.requester_id = ? 
                      ORDER BY sr.created_at DESC");
$stmt->execute([$_SESSION['user_id']]);
$requests = $stmt->fetchAll();

// Get specific request if requested
$currentRequest = null;
if (isset($_GET['id'])) {
    $requestStmt = $pdo->prepare("SELECT sr.*, 
                                 u.username as technician_name,
                                 a.assigned_at,
                                 a.completed_at
                                 FROM service_requests sr 
                                 LEFT JOIN assignments a ON sr.id = a.request_id 
                                 LEFT JOIN users u ON a.technician_id = u.id 
                                 WHERE sr.id = ? AND sr.requester_id = ?");
    $requestStmt->execute([$_GET['id'], $_SESSION['user_id']]);
    $currentRequest = $requestStmt->fetch();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Requests - Online Services Routing System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <?php include __DIR__ . '/../includes/header.php'; ?>
    
    <div class="container mt-4">
        <div class="row">
            <div class="col-md-3">
                <div class="card">
                    <div class="card-header">
                        <h5>Menu</h5>
                    </div>
                    <div class="card-body">
                        <ul class="nav flex-column">
                            <li class="nav-item">
                                <a class="nav-link" href="dashboard.php">Dashboard</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="create_request.php">Create Request</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link active" href="view_requests.php">View Requests</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="notifications.php">Notifications</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="../auth/logout.php">Logout</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="col-md-9">
                <?php if (isset($_GET['created'])): ?>
                    <div class="alert alert-success mb-3">Service request created successfully!</div>
                <?php endif; ?>

                <div class="card">
                    <div class="card-header">
                        <h5>My Service Requests</h5>
                    </div>
                    <div class="card-body">
                        <?php if (count($requests) > 0): ?>
                            <div class="table-responsive">
                                <table class="table table-striped">
                                    <thead>
                                        <tr>
                                            <th>ID</th>
                                            <th>Title</th>
                                            <th>Status</th>
                                            <th>Created</th>
                                            <th>Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($requests as $request): ?>
                                            <tr>
                                                <td><?php echo $request['id']; ?></td>
                                                <td><?php echo htmlspecialchars($request['title']); ?></td>
                                                <td>
                                                    <span class="badge bg-<?php 
                                                        switch($request['status']) {
                                                            case 'pending': echo 'warning'; break;
                                                            case 'assigned': echo 'info'; break;
                                                            case 'in_progress': echo 'primary'; break;
                                                            case 'completed': echo 'success'; break;
                                                            default: echo 'secondary';
                                                        }
                                                    ?>">
                                                        <?php echo ucfirst(str_replace('_', ' ', $request['status'])); ?>
                                                    </span>
                                                </td>
                                                <td><?php echo date('M d, Y', strtotime($request['created_at'])); ?></td>
                                                <td>
                                                    <button type="button" class="btn btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#requestModal<?php echo $request['id']; ?>">
                                                        View Details
                                                    </button>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php else: ?>
                            <div class="alert alert-info">No service requests found.</div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Request Detail Modals -->
    <?php foreach ($requests as $request): ?>
        <div class="modal fade" id="requestModal<?php echo $request['id']; ?>" tabindex="-1" aria-labelledby="requestModalLabel<?php echo $request['id']; ?>" aria-hidden="true">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="requestModalLabel<?php echo $request['id']; ?>">Request Details</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <h4><?php echo htmlspecialchars($request['title']); ?></h4>
                        <p class="text-muted">Created on <?php echo date('M d, Y H:i', strtotime($request['created_at'])); ?></p>
                        
                        <div class="mb-3">
                            <span class="badge bg-<?php 
                                switch($request['status']) {
                                    case 'pending': echo 'warning'; break;
                                    case 'assigned': echo 'info'; break;
                                    case 'in_progress': echo 'primary'; break;
                                    case 'completed': echo 'success'; break;
                                    default: echo 'secondary';
                                }
                            ?>">
                                <?php echo ucfirst(str_replace('_', ' ', $request['status'])); ?>
                            </span>
                        </div>
                        
                        <div class="mb-3">
                            <h6>Description:</h6>
                            <p><?php echo nl2br(htmlspecialchars($request['description'])); ?></p>
                        </div>
                        
                        <?php
                        // Get technician and assignment details
                        $stmt = $pdo->prepare("SELECT u.username as technician_name, a.assigned_at, a.completed_at 
                                             FROM assignments a 
                                             JOIN users u ON a.technician_id = u.id 
                                             WHERE a.request_id = ?");
                        $stmt->execute([$request['id']]);
                        $assignment = $stmt->fetch();
                        
                        if ($assignment): ?>
                            <div class="mb-3">
                                <h6>Assigned Technician:</h6>
                                <p><?php echo htmlspecialchars($assignment['technician_name']); ?></p>
                            </div>
                            
                            <div class="mb-3">
                                <h6>Assignment Details:</h6>
                                <p>Assigned on: <?php echo date('M d, Y H:i', strtotime($assignment['assigned_at'])); ?></p>
                                <?php if ($assignment['completed_at']): ?>
                                    <p>Completed on: <?php echo date('M d, Y H:i', strtotime($assignment['completed_at'])); ?></p>
                                <?php endif; ?>
                            </div>
                        <?php endif; ?>

                        <?php if ($request['status'] === 'completed'): ?>
                            <?php
                            // Get completion pictures
                            $picturesStmt = $pdo->prepare("SELECT cp.*, u.username as technician_name 
                                                         FROM completion_pictures cp 
                                                         JOIN users u ON cp.technician_id = u.id 
                                                         WHERE cp.request_id = ? 
                                                         ORDER BY cp.uploaded_at DESC");
                            $picturesStmt->execute([$request['id']]);
                            $completionPictures = $picturesStmt->fetchAll();
                            
                            // Get report images
                            $reportStmt = $pdo->prepare("SELECT ri.*, tr.created_at as uploaded_at, u.username as technician_name
                                                        FROM technician_reports tr
                                                        JOIN report_images ri ON tr.id = ri.report_id
                                                        JOIN users u ON tr.technician_id = u.id
                                                        WHERE tr.request_id = ?
                                                        ORDER BY tr.created_at DESC");
                            $reportStmt->execute([$request['id']]);
                            $reportImages = $reportStmt->fetchAll();
                            
                            if (count($completionPictures) > 0 || count($reportImages) > 0): ?>
                                <div class="mb-4">
                                    <h5>Completion Pictures</h5>
                                    <div class="row">
                                        <?php foreach ($completionPictures as $picture): ?>
                                            <div class="col-md-4 mb-3">
                                                <div class="card">
                                                    <img src="../<?php echo htmlspecialchars($picture['picture_path']); ?>" 
                                                         class="card-img-top" 
                                                         alt="Completion Picture"
                                                         style="height: 200px; object-fit: cover;">
                                                    <div class="card-body">
                                                        <p class="card-text">
                                                            <small class="text-muted">
                                                                Uploaded by: <?php echo htmlspecialchars($picture['technician_name']); ?><br>
                                                                Date: <?php echo date('M d, Y H:i', strtotime($picture['uploaded_at'])); ?>
                                                            </small>
                                                        </p>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php endforeach; ?>
                                        
                                        <?php foreach ($reportImages as $image): ?>
                                            <div class="col-md-4 mb-3">
                                                <div class="card">
                                                    <img src="../<?php echo htmlspecialchars($image['image_path']); ?>" 
                                                         class="card-img-top" 
                                                         alt="Report Image"
                                                         style="height: 200px; object-fit: cover;">
                                                    <div class="card-body">
                                                        <p class="card-text">
                                                            <small class="text-muted">
                                                                Uploaded by: <?php echo htmlspecialchars($image['technician_name']); ?><br>
                                                                Date: <?php echo date('M d, Y H:i', strtotime($image['uploaded_at'])); ?>
                                                            </small>
                                                        </p>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php endforeach; ?>
                                    </div>
                                </div>
                            <?php endif; ?>
                        <?php endif; ?>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    </div>
                </div>
            </div>
        </div>
    <?php endforeach; ?>

    <?php include __DIR__ . '/../includes/footer.php'; ?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/js/main.js"></script>
</body>
</html> 