<?php
require_once 'config/database.php';
require_once 'includes/auth.php';

// Check if user is logged in
if (!isLoggedIn()) {
    header('Location: auth/login.php');
    exit();
}

$user_id = $_SESSION['user_id'];
$error = '';
$success = '';

// Get user data first
try {
    $stmt = $pdo->prepare("SELECT u.*, c.name as college_name 
                          FROM users u 
                          LEFT JOIN colleges c ON u.college_id = c.id 
                          WHERE u.id = ?");
    $stmt->execute([$user_id]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$user) {
        // If user not found, redirect to login
        session_destroy();
        header('Location: auth/login.php');
        exit();
    }
} catch (PDOException $e) {
    error_log("Error fetching user data: " . $e->getMessage());
    $error = "Failed to load user data. Please try again later.";
}

// Handle profile picture upload
if (isset($_FILES['profile_picture']) && $_FILES['profile_picture']['error'] === UPLOAD_ERR_OK) {
    $allowed_types = ['image/jpeg', 'image/png', 'image/gif'];
    $max_size = 5 * 1024 * 1024; // 5MB
    
    if (!in_array($_FILES['profile_picture']['type'], $allowed_types)) {
        $error = 'Invalid file type. Please upload a JPG, PNG, or GIF image.';
    } elseif ($_FILES['profile_picture']['size'] > $max_size) {
        $error = 'File size too large. Maximum size is 5MB.';
    } else {
        $upload_dir = 'uploads/profile_pictures/';
        $absolute_upload_dir = __DIR__ . '/' . $upload_dir;
        if (!file_exists($absolute_upload_dir)) {
            mkdir($absolute_upload_dir, 0777, true);
        }
        
        $file_extension = pathinfo($_FILES['profile_picture']['name'], PATHINFO_EXTENSION);
        $new_filename = 'profile_' . $user_id . '_' . time() . '.' . $file_extension;
        $upload_path = $upload_dir . $new_filename;
        $absolute_upload_path = $absolute_upload_dir . $new_filename;
        
        if (move_uploaded_file($_FILES['profile_picture']['tmp_name'], $absolute_upload_path)) {
            // Delete old profile picture if exists
            if ($user['profile_picture']) {
                $old_absolute_path = __DIR__ . '/' . $user['profile_picture'];
                if (file_exists($old_absolute_path)) {
                    unlink($old_absolute_path);
                }
            }
            
            // Update database with new profile picture path
            $stmt = $pdo->prepare("UPDATE users SET profile_picture = ? WHERE id = ?");
            $stmt->execute([$upload_path, $user_id]);
            
            // Debug information
            error_log("New profile picture uploaded: " . $upload_path);
            error_log("Absolute path: " . $absolute_upload_path);
            error_log("File exists after upload: " . (file_exists($absolute_upload_path) ? 'Yes' : 'No'));
            
            $success = 'Profile picture updated successfully!';
            
            // Update the user array with new profile picture
            $user['profile_picture'] = $upload_path;
        } else {
            $error = 'Failed to upload profile picture.';
            error_log("Failed to upload profile picture. Error: " . error_get_last()['message']);
        }
    }
}

// Handle profile update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_profile'])) {
    $first_name = trim($_POST['first_name']);
    $last_name = trim($_POST['last_name']);
    $email = trim($_POST['email']);
    $contact_number = trim($_POST['contact_number']);
    $college_id = $_POST['college_id'] ?? null;
    
    if (empty($first_name) || empty($last_name) || empty($email) || empty($contact_number)) {
        $error = 'All fields are required';
    } else {
        try {
            // Check if email is already taken by another user
            $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ? AND id != ?");
            $stmt->execute([$email, $user_id]);
            
            if ($stmt->rowCount() > 0) {
                $error = 'Email is already taken by another user';
            } else {
                // Update user profile
                $stmt = $pdo->prepare("UPDATE users SET first_name = ?, last_name = ?, email = ?, contact_number = ? WHERE id = ?");
                $stmt->execute([$first_name, $last_name, $email, $contact_number, $user_id]);
                
                // Only update college_id for requesters
                if ($user['role'] === 'requester') {
                    $stmt = $pdo->prepare("UPDATE users SET college_id = ? WHERE id = ?");
                    $stmt->execute([$college_id, $user_id]);
                }
                
                $success = 'Profile updated successfully!';
                
                // Update the user array with new values
                $user['first_name'] = $first_name;
                $user['last_name'] = $last_name;
                $user['email'] = $email;
                $user['contact_number'] = $contact_number;
                if ($user['role'] === 'requester') {
                    $user['college_id'] = $college_id;
                }
            }
        } catch (PDOException $e) {
            $error = 'Failed to update profile: ' . $e->getMessage();
        }
    }
}

// Handle account deletion
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_account'])) {
    try {
        // Start transaction
        $pdo->beginTransaction();
        
        // Delete user's profile picture
        $stmt = $pdo->prepare("SELECT profile_picture FROM users WHERE id = ?");
        $stmt->execute([$user_id]);
        $profile_picture = $stmt->fetchColumn();
        
        if ($profile_picture && file_exists($profile_picture)) {
            unlink($profile_picture);
        }
        
        // Delete user's data from related tables
        $tables = ['notifications', 'assignments', 'service_requests', 'technician_reports'];
        foreach ($tables as $table) {
            $stmt = $pdo->prepare("DELETE FROM $table WHERE user_id = ?");
            $stmt->execute([$user_id]);
        }
        
        // Delete user account
        $stmt = $pdo->prepare("DELETE FROM users WHERE id = ?");
        $stmt->execute([$user_id]);
        
        $pdo->commit();
        
        // Clear session and redirect to login
        session_destroy();
        header('Location: auth/login.php');
        exit();
    } catch (PDOException $e) {
        $pdo->rollBack();
        $error = 'Failed to delete account: ' . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Profile - Online Services Routing System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.7.2/font/bootstrap-icons.css" rel="stylesheet">
    <link href="assets/css/style.css" rel="stylesheet">
</head>
<body class="bg-light">
    <?php include 'includes/header.php'; ?>
    
    <div class="container py-5">
        <div class="row">
            <div class="col-md-4">
                <div class="card shadow-sm mb-4">
                    <div class="card-body text-center">
                        <div class="mb-3">
                            <?php if ($user['profile_picture']): ?>
                                <img src="<?php echo htmlspecialchars($user['profile_picture']); ?>" 
                                     alt="Profile Picture" 
                                     class="rounded-circle img-thumbnail"
                                     style="width: 150px; height: 150px; object-fit: cover;">
                            <?php else: ?>
                                <img src="assets/images/default-profile.png" 
                                     alt="Default Profile Picture" 
                                     class="rounded-circle img-thumbnail"
                                     style="width: 150px; height: 150px; object-fit: cover;">
                            <?php endif; ?>
                        </div>
                        
                        <button type="button" class="btn btn-outline-primary mb-3" onclick="toggleUploadForm()">
                            <i class="bi bi-camera"></i> Change Profile Picture
                        </button>
                        
                        <form action="" method="POST" enctype="multipart/form-data" class="mb-3" id="uploadForm" style="display: none;">
                            <div class="mb-3">
                                <label for="profile_picture" class="form-label">Select New Picture</label>
                                <input type="file" class="form-control" id="profile_picture" name="profile_picture" accept="image/*" required>
                                <small class="text-muted">Allowed formats: JPG, PNG, GIF. Max size: 5MB</small>
                            </div>
                            <div class="d-flex gap-2">
                                <button type="submit" class="btn btn-primary">Upload Picture</button>
                                <button type="button" class="btn btn-secondary" onclick="toggleUploadForm()">Cancel</button>
                            </div>
                        </form>
                        
                        <h4><?php echo htmlspecialchars($user['first_name'] . ' ' . $user['last_name']); ?></h4>
                        <p class="text-muted"><?php echo htmlspecialchars($user['role']); ?></p>
                        <?php if ($user['college_name']): ?>
                            <p class="text-muted"><?php echo htmlspecialchars($user['college_name']); ?></p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            
            <div class="col-md-8">
                <div class="card shadow-sm">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h3 class="card-title mb-0">Edit Profile</h3>
                        <a href="<?php echo isAdmin() ? 'admin/dashboard.php' : (isTechnician() ? 'technicians/dashboard.php' : 'requesters/dashboard.php'); ?>" 
                           class="btn btn-secondary">
                            <i class="bi bi-arrow-left"></i> Back to Dashboard
                        </a>
                    </div>
                    <div class="card-body">
                        <?php if ($error): ?>
                            <div class="alert alert-danger"><?php echo $error; ?></div>
                        <?php endif; ?>
                        
                        <?php if ($success): ?>
                            <div class="alert alert-success">
                                <?php echo $success; ?>
                            </div>
                        <?php endif; ?>
                        
                        <form method="POST" action="">
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">First Name</label>
                                    <input type="text" class="form-control" name="first_name" 
                                           value="<?php echo htmlspecialchars($user['first_name']); ?>" required>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Last Name</label>
                                    <input type="text" class="form-control" name="last_name" 
                                           value="<?php echo htmlspecialchars($user['last_name']); ?>" required>
                                </div>
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">Email</label>
                                <input type="email" class="form-control" name="email" 
                                       value="<?php echo htmlspecialchars($user['email']); ?>" required>
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">Contact Number</label>
                                <input type="tel" class="form-control" name="contact_number" 
                                       value="<?php echo isset($user['contact_number']) ? htmlspecialchars($user['contact_number']) : ''; ?>" required>
                            </div>
                            
                            <?php if ($user['role'] === 'requester'): ?>
                                <div class="mb-3">
                                    <label class="form-label">College</label>
                                    <select class="form-select" name="college_id" required>
                                        <?php
                                        $colleges = $pdo->query("SELECT * FROM colleges ORDER BY name")->fetchAll();
                                        foreach ($colleges as $college) {
                                            $selected = ($college['id'] == $user['college_id']) ? 'selected' : '';
                                            echo "<option value='{$college['id']}' {$selected}>{$college['name']} ({$college['code']})</option>";
                                        }
                                        ?>
                                    </select>
                                </div>
                            <?php endif; ?>
                            
                            <div class="d-flex justify-content-between">
                                <button type="submit" name="update_profile" class="btn btn-primary">Update Profile</button>
                                <button type="button" class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#deleteAccountModal">
                                    Delete Account
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Delete Account Modal -->
    <div class="modal fade" id="deleteAccountModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Delete Account</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <p>Are you sure you want to delete your account? This action cannot be undone.</p>
                    <p class="text-danger">All your data, including service requests and reports, will be permanently deleted.</p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <form method="POST" action="" class="d-inline">
                        <button type="submit" name="delete_account" class="btn btn-danger">Delete Account</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    
    <?php include 'includes/footer.php'; ?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function toggleUploadForm() {
            const uploadForm = document.getElementById('uploadForm');
            if (uploadForm.style.display === 'none') {
                uploadForm.style.display = 'block';
            } else {
                uploadForm.style.display = 'none';
                // Reset the file input
                document.getElementById('profile_picture').value = '';
            }
        }
    </script>
</body>
</html> 